
public class auto {
	int counttemp = 0;

	public void make(String a) {
		String prefixname = "All" + a + "n";
		int temp = 0;

		for (int i = 0; i <= 138; i = i + 4) {

			String navn = prefixname + i + "";
			System.out.println("<Button");
			System.out.println("android:id=\"@+id/" + navn + "\"");
			System.out.println("android:layout_marginTop=\"5dp\"");
			System.out.println("android:layout_width=\"match_parent\"");
			System.out.println("android:layout_height=\"wrap_content\"");
			System.out.println("android:text=\"" + navn + "\" ");
			System.out.println("android:onClick=\"" + navn + "\"");
			System.out.println("/>");
			System.out.println("");

			temp++;
			if (temp > 5) {
				temp = 0;
				counttemp++;
				System.out.println("<Button");
				System.out.println("android:id=\"@+id/" + "temp" + counttemp + "\"");
				System.out.println("android:layout_marginTop=\"5dp\"");
				System.out.println("android:layout_width=\"match_parent\"");
				System.out.println("android:layout_height=\"wrap_content\"");
				System.out.println("android:text=\"walking\" ");
				System.out.println("android:background=\"@color/green\"");
				System.out.println("android:onClick=\"walking\"");
				System.out.println("/>");
				System.out.println("");

			}

		}

		System.out.println("<Button");
		System.out.println("android:id=\"@+id/skifte" + a + "\"");
		System.out.println("android:layout_marginTop=\"55dp\"");
		System.out.println("android:layout_width=\"match_parent\"");
		System.out.println("android:layout_height=\"wrap_content\"");
		System.out.println("android:text=\"skift\" ");
		System.out.println("android:background=\"@color/red\"");
		System.out.println("android:onClick=\"skift\"");
		System.out.println("/>");
		System.out.println("");

		for (int i = 139; i <= 178; i = i + 4) {

			String navn = prefixname + i + "";
			System.out.println("<Button");
			System.out.println("android:id=\"@+id/" + navn + "\"");
			System.out.println("android:layout_marginTop=\"5dp\"");
			System.out.println("android:layout_width=\"match_parent\"");
			System.out.println("android:layout_height=\"wrap_content\"");
			System.out.println("android:text=\"" + navn + "\" ");
			System.out.println("android:onClick=\"" + navn + "\"");
			System.out.println("/>");
			System.out.println("");

			temp++;
			if (temp > 5) {
				temp = 0;
				counttemp++;
				System.out.println("<Button");
				System.out.println("android:id=\"@+id/" + "temp" + counttemp + "\"");
				System.out.println("android:layout_marginTop=\"5dp\"");
				System.out.println("android:layout_width=\"match_parent\"");
				System.out.println("android:layout_height=\"wrap_content\"");
				System.out.println("android:text=\"walking\" ");
				System.out.println("android:background=\"@color/green\"");
				System.out.println("android:onClick=\"walking\"");
				System.out.println("/>");
				System.out.println("");

			}
		}

		System.out.println("<Button");
		System.out.println("android:id=\"@+id/skiftee" + a + "\"");
		System.out.println("android:layout_marginTop=\"55dp\"");
		System.out.println("android:layout_width=\"match_parent\"");
		System.out.println("android:layout_height=\"wrap_content\"");
		System.out.println("android:text=\"skift\" ");
		System.out.println("android:background=\"@color/red\"");
		System.out.println("android:onClick=\"skift\"");
		System.out.println("/>");
		System.out.println("");

		for (int i = 179; i <= 476; i = i + 4) {

			String navn = prefixname + i + "";
			System.out.println("<Button");
			System.out.println("android:id=\"@+id/" + navn + "\"");
			System.out.println("android:layout_marginTop=\"5dp\"");
			System.out.println("android:layout_width=\"match_parent\"");
			System.out.println("android:layout_height=\"wrap_content\"");
			System.out.println("android:text=\"" + navn + "\" ");
			System.out.println("android:onClick=\"" + navn + "\"");
			System.out.println("/>");
			System.out.println("");

			temp++;
			if (temp > 5) {
				temp = 0;
				counttemp++;
				System.out.println("<Button");
				System.out.println("android:id=\"@+id/" + "temp" + counttemp + "\"");
				System.out.println("android:layout_marginTop=\"5dp\"");
				System.out.println("android:layout_width=\"match_parent\"");
				System.out.println("android:layout_height=\"wrap_content\"");
				System.out.println("android:text=\"walking\" ");
				System.out.println("android:background=\"@color/green\"");
				System.out.println("android:onClick=\"walking\"");
				System.out.println("/>");
				System.out.println("");

			}
		}

	}

	public void make2(String a) {
		String prefixname = "All" + a + "n";

		for (int i = 0; i <= 138; i = i + 4) {

			String navn = prefixname + i + "";
			System.out.println("public void " + navn + "(View v) {");
			System.out.println("positionX = " + a + ";");
			System.out.println("positionY = " + i + ";");
			System.out.println("}");
		}

		for (int i = 139; i <= 178; i = i + 4) {
			String navn = prefixname + i + "";
			System.out.println("public void " + navn + "(View v) {");
			System.out.println("positionX = " + a + ";");
			System.out.println("positionY = " + i + ";");
			System.out.println("}");

		}

		for (int i = 179; i <= 476; i = i + 4) {
			String navn = prefixname + i + "";
			System.out.println("public void " + navn + "(View v) {");
			System.out.println("positionX = " + a + ";");
			System.out.println("positionY = " + i + ";");
			System.out.println("}");
		}

	}

	public void make3() {

		String[] temp = { "5,5", "11,4", "25,7", "*", "45,7", "58,3", "66,2", "*", "77,8", "95,5", "111,5", "121,4",
				"147,2", "163,2",

				"175,2", "184,3", "200,3", "*", "206,3", "227,8", "249,4", "260,3", "*", "281,4", "307,2",

				"*", "317,2", "*", "347,2", "363,2", "*", "393,4", "*", "402,6", "417,5", "431,5", "443,6", "454,6", };

		int tempIntNavn = 0;
		int temp123 = 0;
		for (int i = 0; i < temp.length; i++) {

			if (temp[i] != "*") {

				System.out.println("<Button");
				System.out.println("android:id=\"@+id/" + "aa" + "jj" + tempIntNavn + "\"");
				System.out.println("android:layout_marginTop=\"5dp\"");
				System.out.println("android:layout_width=\"match_parent\"");
				System.out.println("android:layout_height=\"wrap_content\"");
				System.out.println("android:text=\"" + temp[i] + "\" ");
				System.out.println("android:onClick=\"" + "aa" + "jj" + tempIntNavn + "\"");
				System.out.println("/>");
				System.out.println("");

				temp123++;
				if (temp123 > 5) {
					temp123 = 0;
					counttemp++;
					System.out.println("<Button");
					System.out.println("android:id=\"@+id/" + "temp" + counttemp + "\"");
					System.out.println("android:layout_marginTop=\"5dp\"");
					System.out.println("android:layout_width=\"match_parent\"");
					System.out.println("android:layout_height=\"wrap_content\"");
					System.out.println("android:text=\"walking\" ");
					System.out.println("android:background=\"@color/green\"");
					System.out.println("android:onClick=\"walking\"");
					System.out.println("/>");
					System.out.println("");

				}

				tempIntNavn++;
			} else {

				System.out.println("<Button");
				System.out.println("android:id=\"@+id/" + "jj" + tempIntNavn + "\"");
				System.out.println("android:layout_marginTop=\"5dp\"");
				System.out.println("android:layout_width=\"match_parent\"");
				System.out.println("android:layout_height=\"wrap_content\"");
				System.out.println("android:text=\"******\" ");
				System.out.println("android:onClick=\"ghjk\"");
				System.out.println("/>");
				System.out.println("");

				temp123++;
				if (temp123 > 5) {
					temp123 = 0;
					counttemp++;
					System.out.println("<Button");
					System.out.println("android:id=\"@+id/" + "temp" + counttemp + "\"");
					System.out.println("android:layout_marginTop=\"5dp\"");
					System.out.println("android:layout_width=\"match_parent\"");
					System.out.println("android:layout_height=\"wrap_content\"");
					System.out.println("android:text=\"walking\" ");
					System.out.println("android:background=\"@color/green\"");
					System.out.println("android:onClick=\"walking\"");
					System.out.println("/>");
					System.out.println("");

				}

				tempIntNavn++;
			}
		}

	}

	public void make4() {

		String[] temp = { "5,5", "11,4", "25,7", "*", "45,7", "58,3", "66,2", "*", "77,8", "95,5", "111,5", "121,4",
				"147,2", "163,2",

				"175,2", "184,3", "200,3", "*", "206,3", "227,8", "249,4", "260,3", "*", "281,4", "307,2",

				"*", "317,2", "*", "347,2", "363,2", "*", "393,4", "*", "402,6", "417,5", "431,5", "443,6", "454,6", };

		int tempIntNavn = 0;

		for (int i = 0; i < temp.length; i++) {

			if (temp[i] != "*") {

				String[] parts = temp[i].split(",");
				String navn = "aa" + "jj" + tempIntNavn;
				System.out.println("public void " + navn + "(View v) {");
				System.out.println("positionX = " + parts[0] + ";");
				System.out.println("positionY = " + parts[1] + ";");
				System.out.println("}");

				tempIntNavn++;
			} else {
				tempIntNavn++;
			}
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		auto s = new auto();

		s.make3();
		/*
		 * s.make("2"); s.make("6"); s.make("10"); s.make("14");
		 */

		/*
		 * s.make2("2"); s.make2("6"); s.make2("10"); s.make2("14");
		 * 
		 */

	}

}
