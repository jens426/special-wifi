import java.util.ArrayList;

public class Euclidean implements Comparable<Euclidean> {

	double distance = 0;
	SamplePoint a;

	public SamplePoint getSampleA() {
		return a;
	}

	public void setA(SamplePoint a) {
		this.a = a;
	}

	public SamplePoint getSampleB() {
		return b;
	}

	public void setB(SamplePoint b) {
		this.b = b;
	}

	SamplePoint b;

	public double getDistance() {

		return distance;
	}

	// a has to be the testcase
	public void calculateDisPenaltyZero(SamplePoint a, SamplePoint b) {
		this.a = a;
		this.b = b;

		distance = 0;
		ArrayList<WifiPoint> aWifi = new ArrayList();
		ArrayList<WifiPoint> bWifi = new ArrayList();

		aWifi = a.getAllWifi();
		bWifi = b.getAllWifi();

		double result = 0;

		for (WifiPoint temp : aWifi) {

			double find = 0;
			for (WifiPoint temp2 : bWifi) {
				if (temp.getWifiname().toString().equals(temp2.getWifiname().toString())) {
					find = temp2.getStregth();
					// System.out.println("ens");
					break;
				} else {

					// System.out.println("ikke");
				}

			}

			// if (find == 0)
			// System.out.println("-----------------------------------");
			// System.out.println(find);

			result = result + Math.pow((temp.getStregth() - find), 2);
			// double oo = temp.getStregth()-find;
			// System.out.println(temp.getStregth()+":"+find+":"+Math.pow(oo,2));

		}
		// System.out.println(result);
		distance = Math.sqrt(result);

		// System.out.println(distance);

	}

	public void calculateDisPenaltyHundred(SamplePoint a, SamplePoint b) {
		this.a = a;
		this.b = b;

		distance = 0;
		ArrayList<WifiPoint> aWifi = new ArrayList();
		ArrayList<WifiPoint> bWifi = new ArrayList();

		aWifi = a.getAllWifi();
		bWifi = b.getAllWifi();

		double result = 0;

		for (WifiPoint temp : aWifi) {

			double find = 0;
			for (WifiPoint temp2 : bWifi) {
				if (temp.getWifiname().toString().equals(temp2.getWifiname().toString())) {
					find = temp2.getStregth();
					// System.out.println("ens");
					break;
				} else {

					// System.out.println("ikke");
				}

			}

			if (find == 0)
				find = -100;
			// System.out.println(find);

			result = result + Math.pow((temp.getStregth() - find), 2);
			// double oo = temp.getStregth()-find;
			// System.out.println(temp.getStregth()+":"+find+":"+Math.pow(oo,2));

		}
		// System.out.println(result);
		distance = Math.sqrt(result);

		// System.out.println(distance);

	}

	public void calculateDisAllThere(SamplePoint a, SamplePoint b) {
		this.a = a;
		this.b = b;

		distance = 0;
		ArrayList<WifiPoint> aWifi = new ArrayList();
		ArrayList<WifiPoint> bWifi = new ArrayList();

		aWifi = a.getAllWifi();
		bWifi = b.getAllWifi();

		int numbers = 0;

		for (WifiPoint temp : aWifi) {

			for (WifiPoint temp2 : bWifi) {

				if (temp.getWifiname().toString().equals(temp2.getWifiname().toString())) {
					numbers++;
					break;

				}

			}

		}

		// System.out.println(aWifi.size()+"a");
		// System.out.println(bWifi.size()+"b");
		// System.out.println(numbers+"number \n");

		if (numbers >= aWifi.size() * 0.80) {
			double result = 0;
			for (WifiPoint temp : aWifi) {

				double find = 0;
				for (WifiPoint temp2 : bWifi) {
					if (temp.getWifiname().toString().equals(temp2.getWifiname().toString())) {
						find = temp2.getStregth();
						// System.out.println("ens");
						break;
					} else {

						// System.out.println("ikke");
					}

				}

				if (find == 0)
					find = -100;
				// System.out.println(find);

				result = result + Math.pow((temp.getStregth() - find), 2);
				// double oo = temp.getStregth()-find;
				// System.out.println(temp.getStregth()+":"+find+":"+Math.pow(oo,2));

			}
			// System.out.println(result);
			distance = Math.sqrt(result);

			// System.out.println(distance);
		} else {
			distance = 999999999;
		}

	}

	@Override
	public int compareTo(Euclidean arg0) {

		return (int) (1000 * (distance - arg0.getDistance()));
	}

}
