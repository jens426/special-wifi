import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class ProcessData {

	// all allowed wifi names
	ArrayList<WifiPoint> filter = new ArrayList();

	// used to count at wifi position 1 to 7 x and y set to -100,-700
	ArrayList<SamplePoint> countWIFI = new ArrayList();

	// fingerprinting all data
	ArrayList<SamplePoint> alldata = new ArrayList();

	// testdata right direction
	ArrayList<SamplePoint> testDataRight = new ArrayList();

	// testdata wrong direction
	ArrayList<SamplePoint> testDataWrong = new ArrayList();

	// testdata tablet right direction
	ArrayList<SamplePoint> testDataTabletRight = new ArrayList();

	// longRun
	ArrayList<SamplePoint> longRunData = new ArrayList();

	// longRun doppeldata
	ArrayList<SamplePoint> longRunData2 = new ArrayList();

	// shortrun data
	ArrayList<SamplePoint> shortRunData = new ArrayList();

	static String readFile(String path, Charset encoding) throws IOException {
		byte[] encoded = Files.readAllBytes(Paths.get(path));
		return new String(encoded, encoding);
	}

	// remove wifi name i think is not relevant
	public void createFilter() {

		String content = "";
		try {
			content = readFile("all.txt", StandardCharsets.UTF_8);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		content = content.replace("\n", "").replace("\r", "");
		String[] parts = content.split(",");

		long lastTimeStamp = 0;
		int i = 0;

		while (i < parts.length) {
			int x = 0;
			int y = 0;

			if ((parts[i].toString().equals("-1.0"))) {
				x = -1;
			} else
				x = Integer.parseInt(parts[i].toString());
			i++;
			if ((parts[i].toString().equals("-1.0"))) {
				y = -1;
			} else
				y = Integer.parseInt(parts[i].toString());
			i++;
			// System.out.println(parts[i]);
			i++;
			String name = parts[i];
			// System.out.println(parts[i]);
			i++;
			int stregth = Integer.parseInt(parts[i]);
			// System.out.println(parts[i]);

			WifiPoint toAdd = new WifiPoint(name, stregth);
			Boolean contains = false;

			for (WifiPoint temp : filter) {
				if (temp.getWifiname().toString().equals(toAdd.getWifiname())) {
					contains = true;

					if (stregth > -90)
						temp.numberOfTimes++;
					break;
				}

			}

			if (contains == false) {

				filter.add(toAdd);
			}

			i++;
			i++;

		}

		// remove all that have been seen less that 200 times

		ArrayList<WifiPoint> filter2 = new ArrayList();

		for (WifiPoint temp : filter) {
			// System.out.println(temp.numberOfTimes+"");
			if (temp.numberOfTimes > 50)
				filter2.add(temp);

		}

		filter = filter2;

		// System.out.println(filter.size());
		// System.out.println(content);

	}

	// used to find out how many wifi signals there are at wifi1 to wifi7
	public void offline1() {

		String content = "";
		try {
			content = readFile("wifi1to7.txt", StandardCharsets.UTF_8);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		content = content.replace("\n", "").replace("\r", "");
		String[] parts = content.split(",");

		long lastTimeStamp = 0;
		int i = 0;
		SamplePoint lastSamplePoint = null;
		int sum = 0;
		int div = 0;
		while (i < parts.length) {
			int x = 0;
			int y = 0;

			if ((parts[i].toString().equals("-1.0"))) {
				x = -1;
			} else
				x = Integer.parseInt(parts[i].toString());
			i++;
			if ((parts[i].toString().equals("-1.0"))) {
				y = -1;
			} else
				y = Integer.parseInt(parts[i].toString());
			i++;
			// System.out.println(parts[i]);
			i++;
			String name = parts[i];
			// System.out.println(parts[i]);
			i++;
			int stregth = Integer.parseInt(parts[i]);
			// System.out.println(parts[i]);

			WifiPoint toAdd = new WifiPoint(name, stregth);
			Boolean contains = false;

			i++;

			// countWIFI

			long TimeStampNow = Long.parseLong(parts[i].toString());

			if (TimeStampNow != lastTimeStamp) {

				SamplePoint tempSamplePoint = new SamplePoint(x, y);
				countWIFI.add(tempSamplePoint);

				Boolean contains2 = false;

				for (WifiPoint temp : filter) {
					if (temp.getWifiname().toString().equals(toAdd.getWifiname())) {
						contains2 = true;
						temp.numberOfTimes++;
						break;
					}

				}

				// if a wifiname not is in the filter list remove it
				if (contains2 == true)
					tempSamplePoint.addWifiPoint(new WifiPoint(name, stregth));

				lastSamplePoint = tempSamplePoint;

			} else {
				lastSamplePoint.addWifiPoint(new WifiPoint(name, stregth));
			}

			lastTimeStamp = TimeStampNow;

			i++;
			// System.out.println(i);

		}

		for (SamplePoint temp : countWIFI) {
			// System.out.println(temp.numberOfTimes+"");

			if (temp.getX() == -100) {
				// System.out.println(temp.getX()+","+temp.getY());
				sum = sum + temp.getAllWifi().size();
				div++;
				// System.out.println(temp.getAllWifi().size());

				System.out.println();

				int tt = 0;
				for (WifiPoint temp123 : temp.getAllWifi()) {
					tt++;
					if (tt < 6)
						System.out.println(temp123.getWifiname() + "," + temp123.getStregth());

				}
			}

		}
		int temp44 = sum / div;
		// System.out.println(temp44+"--");
		// System.out.println(countWIFI.size());

		System.out.println();

	}

	public void sameSpot() {

		String content = "";
		try {
			content = readFile("sameSpot.txt", StandardCharsets.UTF_8);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		content = content.replace("\n", "").replace("\r", "");
		String[] parts = content.split(",");

		long lastTimeStamp = 0;
		int i = 0;
		SamplePoint lastSamplePoint = null;
		int sum = 0;
		int div = 0;
		while (i < parts.length) {
			int x = 0;
			int y = 0;

			if ((parts[i].toString().equals("-1.0"))) {
				x = -1;
			} else
				x = Integer.parseInt(parts[i].toString());
			i++;
			if ((parts[i].toString().equals("-1.0"))) {
				y = -1;
			} else
				y = Integer.parseInt(parts[i].toString());
			i++;
			// System.out.println(parts[i]);
			i++;
			String name = parts[i];
			// System.out.println(parts[i]);
			i++;
			int stregth = Integer.parseInt(parts[i]);
			// System.out.println(parts[i]);

			WifiPoint toAdd = new WifiPoint(name, stregth);
			Boolean contains = false;

			i++;

			long TimeStampNow = Long.parseLong(parts[i].toString());

			if (TimeStampNow != lastTimeStamp) {

				SamplePoint tempSamplePoint = new SamplePoint(x, y);
				countWIFI.add(tempSamplePoint);

				Boolean contains2 = false;

				for (WifiPoint temp : filter) {
					if (temp.getWifiname().toString().equals(toAdd.getWifiname())) {
						contains2 = true;
						temp.numberOfTimes++;
						break;
					}

				}

				// if a wifiname not is in the filter don't add it
				if (contains2 == true)
					tempSamplePoint.addWifiPoint(new WifiPoint(name, stregth));

				lastSamplePoint = tempSamplePoint;

			} else {
				lastSamplePoint.addWifiPoint(new WifiPoint(name, stregth));
			}

			lastTimeStamp = TimeStampNow;

			i++;
			// System.out.println(i);

		}

		ArrayList<Integer> q = new ArrayList();
		ArrayList<Integer> w = new ArrayList();
		ArrayList<Integer> e = new ArrayList();
		ArrayList<Integer> r = new ArrayList();
		ArrayList<Integer> t = new ArrayList();
		ArrayList<Integer> y = new ArrayList();
		ArrayList<Integer> u = new ArrayList();

		for (SamplePoint temp : countWIFI) {
			// System.out.println(temp.numberOfTimes+"");

			// System.out.println(temp.getX()+","+temp.getY());
			sum = sum + temp.getAllWifi().size();
			div++;
			// System.out.println(temp.getAllWifi().size());

			System.out.println();

			int tt = 0;
			/*
			 * for (WifiPoint temp123 : temp.getAllWifi()) { tt++; // if (tt <
			 * 8) if (
			 * (temp123.getWifiname().toString().equals("00:19:a9:57:d7:22")) ||
			 * (temp123.getWifiname().toString().equals("00:19:a9:57:d7:20")) ||
			 * (temp123.getWifiname().toString().equals("d4:6d:50:e3:9c:ff")) ||
			 * (temp123.getWifiname().toString().equals("00:19:a9:57:d7:23")) ||
			 * (temp123.getWifiname().toString().equals("7c:03:d8:d5:18:8e")) ||
			 * (temp123.getWifiname().toString().equals("d4:6d:50:e7:a7:3f")) ||
			 * (temp123.getWifiname().toString().equals("00:19:a9:57:15:e2"))
			 * 
			 * )
			 * System.out.println(temp123.getWifiname()+","+temp123.getStregth()
			 * );
			 * 
			 * 
			 * }
			 * 
			 * 
			 * 
			 * 
			 * 
			 * 
			 * }
			 */

			q.add(temp.getWifiStregth("00:19:a9:57:d7:22"));
			w.add(temp.getWifiStregth("00:19:a9:57:d7:20"));
			e.add(temp.getWifiStregth("d4:6d:50:e3:9c:ff"));
			r.add(temp.getWifiStregth("00:19:a9:57:d7:23"));
			t.add(temp.getWifiStregth("7c:03:d8:d5:18:8e"));
			y.add(temp.getWifiStregth("d4:6d:50:e7:a7:3f"));
			u.add(temp.getWifiStregth("00:19:a9:57:15:e2"));

		}

		System.out.println(q);
		System.out.println(w);
		System.out.println(e);
		System.out.println(r);
		System.out.println(t);
		System.out.println(y);
		System.out.println(u);
		System.out.println(i);

		int temp44 = sum / div;
		// System.out.println(temp44+"--");
		// System.out.println(countWIFI.size());

		// System.out.println(x);
		System.out.println("number of samplePoint " + countWIFI.size());

	}

	public void createFingerPrint() {
		String content = "";
		try {
			content = readFile("offelineMapAll.txt", StandardCharsets.UTF_8);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		content = content.replace("\n", "").replace("\r", "");
		String[] parts = content.split(",");

		long lastTimeStamp = 0;
		int i = 0;
		SamplePoint lastSamplePoint = null;
		int sum = 0;
		int div = 0;
		while (i < parts.length) {
			int x = 0;
			int y = 0;

			if ((parts[i].toString().equals("-1.0"))) {
				x = -1;
			} else
				x = Integer.parseInt(parts[i].toString());
			i++;
			if ((parts[i].toString().equals("-1.0"))) {
				y = -1;
			} else
				y = Integer.parseInt(parts[i].toString());
			i++;
			// System.out.println(parts[i]);
			i++;
			String name = parts[i];
			// System.out.println(parts[i]);
			i++;
			int stregth = Integer.parseInt(parts[i]);
			// System.out.println(parts[i]);

			WifiPoint toAdd = new WifiPoint(name, stregth);
			Boolean contains = false;

			i++;

			long TimeStampNow = Long.parseLong(parts[i].toString());

			if (TimeStampNow != lastTimeStamp) {

				// swapped x,y because done wrong in collection fase
				SamplePoint tempSamplePoint = new SamplePoint(y, x);
				// don't add if walking x = -1 equal walking
				if (x != -1)
					alldata.add(tempSamplePoint);

				Boolean contains2 = false;

				for (WifiPoint temp : filter) {
					if (temp.getWifiname().toString().equals(toAdd.getWifiname())) {
						contains2 = true;
						temp.numberOfTimes++;
						break;
					}

				}

				// if a wifiname not is in the filter don't add it
				if (contains2 == true)
					tempSamplePoint.addWifiPoint(new WifiPoint(name, stregth));

				lastSamplePoint = tempSamplePoint;

			} else {
				lastSamplePoint.addWifiPoint(new WifiPoint(name, stregth));
			}

			lastTimeStamp = TimeStampNow;

			i++;
			// System.out.println(i);

		}

		// int ii = 0;
		// for (SamplePoint temp : alldata) {
		// System.out.println(temp.getX()+" "+temp.getY());
		// ii++;
		// System.out.println(ii+"dd");
		// }

		// System.out.println(alldata.get(10).getAllWifi());

		// System.out.println("number of samplePoint "+alldata.size());
		// System.out.println("number of WifiSignals "+parts.length);

	}

	// create test data right direction
	public void testData1() {
		String content = "";
		try {
			content = readFile("testDataRightDirection.txt", StandardCharsets.UTF_8);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		content = content.replace("\n", "").replace("\r", "");
		String[] parts = content.split(",");

		long lastTimeStamp = 0;
		int i = 0;
		SamplePoint lastSamplePoint = null;
		int sum = 0;
		int div = 0;
		while (i < parts.length) {
			int x = 0;
			int y = 0;

			if ((parts[i].toString().equals("-1.0"))) {
				x = -1;
			} else
				x = Integer.parseInt(parts[i].toString());
			i++;
			if ((parts[i].toString().equals("-1.0"))) {
				y = -1;
			} else
				y = Integer.parseInt(parts[i].toString());
			i++;
			// System.out.println(parts[i]);
			i++;
			String name = parts[i];
			// System.out.println(parts[i]);
			i++;
			int stregth = Integer.parseInt(parts[i]);
			// System.out.println(parts[i]);

			WifiPoint toAdd = new WifiPoint(name, stregth);
			Boolean contains = false;

			i++;

			long TimeStampNow = Long.parseLong(parts[i].toString());

			if (TimeStampNow != lastTimeStamp) {

				SamplePoint tempSamplePoint = new SamplePoint(x, y);
				// don't add if walking x = -1 equal walking
				if (x != -1)
					testDataRight.add(tempSamplePoint);

				Boolean contains2 = false;

				for (WifiPoint temp : filter) {
					if (temp.getWifiname().toString().equals(toAdd.getWifiname())) {
						contains2 = true;
						temp.numberOfTimes++;
						break;
					}

				}

				// if a wifiname not is in the filter don't add it
				if (contains2 == true)

					tempSamplePoint.addWifiPoint(new WifiPoint(name, stregth));

				lastSamplePoint = tempSamplePoint;

			} else {
				lastSamplePoint.addWifiPoint(new WifiPoint(name, stregth));
			}

			lastTimeStamp = TimeStampNow;

			i++;
			// System.out.println(i);

		}

		// remove if there are samplePoint with the same x coordinate.
		int yy = 0;
		for (int tt = 0; tt < testDataRight.size(); tt++) {

			if (tt != 0) {
				if ((testDataRight.get(tt).getX() == testDataRight.get(tt - 1).getX())
						&& (testDataRight.get(tt).getY() == testDataRight.get(tt - 1).getY())) {
					testDataRight.remove(tt - 1);
				}
			}

		}

		// int ii = 0;
		// for (SamplePoint temp : alldata) {
		// System.out.println(temp.getX()+" "+temp.getY());
		// ii++;
		// System.out.println(ii+"dd");
		// }

		// System.out.println(alldata.get(10).getAllWifi());

		/*
		 * Euclidean test = new Euclidean();
		 * 
		 * 
		 * int from = 18; int to = 18;
		 * 
		 * System.out.println(testDataRight.get(from).getX()+":"+testDataRight.
		 * get(from).getY());
		 * System.out.println(alldata.get(to).getX()+":"+alldata.get(to).getY())
		 * ; test.calculateDisPenaltyZero(testDataRight.get(from),
		 * alldata.get(to)); System.out.println(test.getDistance());
		 * System.out.println();
		 * 
		 * from = 18; to = 45;
		 * 
		 * System.out.println(testDataRight.get(from).getX()+":"+testDataRight.
		 * get(from).getY());
		 * System.out.println(alldata.get(to).getX()+":"+alldata.get(to).getY())
		 * ; test.calculateDisPenaltyZero(testDataRight.get(from),
		 * alldata.get(to)); System.out.println(test.getDistance());
		 * System.out.println();
		 * 
		 * 
		 * from = 18; to = 18;
		 * System.out.println(testDataRight.get(from).getX()+":"+testDataRight.
		 * get(from).getY());
		 * System.out.println(testDataRight.get(from).getX()+":"+testDataRight.
		 * get(from).getY());
		 * test.calculateDisPenaltyZero(testDataRight.get(from),
		 * testDataRight.get(from)); System.out.println(test.getDistance());
		 * System.out.println();
		 * 
		 * 
		 * //System.out.println("number of samplePoint "+testDataRight.size());
		 * //System.out.println("number of WifiSignals "+parts.length);
		 * 
		 */

	}

	// create test data wrong direction
	public void testData2() {
		String content = "";
		try {
			content = readFile("testDataWrongDirection.txt", StandardCharsets.UTF_8);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		content = content.replace("\n", "").replace("\r", "");
		String[] parts = content.split(",");

		long lastTimeStamp = 0;
		int i = 0;
		SamplePoint lastSamplePoint = null;
		int sum = 0;
		int div = 0;
		while (i < parts.length) {
			int x = 0;
			int y = 0;

			if ((parts[i].toString().equals("-1.0"))) {
				x = -1;
			} else
				x = Integer.parseInt(parts[i].toString());
			i++;
			if ((parts[i].toString().equals("-1.0"))) {
				y = -1;
			} else
				y = Integer.parseInt(parts[i].toString());
			i++;
			// System.out.println(parts[i]);
			i++;
			String name = parts[i];
			// System.out.println(parts[i]);
			i++;
			int stregth = Integer.parseInt(parts[i]);
			// System.out.println(parts[i]);

			WifiPoint toAdd = new WifiPoint(name, stregth);
			Boolean contains = false;

			i++;

			long TimeStampNow = Long.parseLong(parts[i].toString());

			if (TimeStampNow != lastTimeStamp) {

				SamplePoint tempSamplePoint = new SamplePoint(x, y);
				// don't add if walking x = -1 equal walking
				if (x != -1)
					testDataWrong.add(tempSamplePoint);

				Boolean contains2 = false;

				for (WifiPoint temp : filter) {
					if (temp.getWifiname().toString().equals(toAdd.getWifiname())) {
						contains2 = true;
						temp.numberOfTimes++;
						break;
					}

				}

				// if a wifiname not is in the filter don't add it
				if (contains2 == true)

					tempSamplePoint.addWifiPoint(new WifiPoint(name, stregth));

				lastSamplePoint = tempSamplePoint;

			} else {
				lastSamplePoint.addWifiPoint(new WifiPoint(name, stregth));
			}

			lastTimeStamp = TimeStampNow;

			i++;
			// System.out.println(i);

		}

		// remove if there are samplePoint with the same x coordinate.
		int yy = 0;
		for (int tt = 0; tt < testDataWrong.size(); tt++) {

			if (tt != 0) {
				if ((testDataWrong.get(tt).getX() == testDataWrong.get(tt - 1).getX())
						&& (testDataWrong.get(tt).getY() == testDataWrong.get(tt - 1).getY())) {
					testDataWrong.remove(tt - 1);
				}
			}

		}

		// int ii = 0;
		// for (SamplePoint temp : alldata) {
		// System.out.println(temp.getX()+" "+temp.getY());
		// ii++;
		// System.out.println(ii+"dd");
		// }

		// System.out.println(alldata.get(10).getAllWifi());

		/*
		 * Euclidean test = new Euclidean();
		 * 
		 * 
		 * int from = 18; int to = 18;
		 * 
		 * System.out.println(testDataRight.get(from).getX()+":"+testDataRight.
		 * get(from).getY());
		 * System.out.println(alldata.get(to).getX()+":"+alldata.get(to).getY())
		 * ; test.calculateDisPenaltyZero(testDataRight.get(from),
		 * alldata.get(to)); System.out.println(test.getDistance());
		 * System.out.println();
		 * 
		 * from = 18; to = 45;
		 * 
		 * System.out.println(testDataRight.get(from).getX()+":"+testDataRight.
		 * get(from).getY());
		 * System.out.println(alldata.get(to).getX()+":"+alldata.get(to).getY())
		 * ; test.calculateDisPenaltyZero(testDataRight.get(from),
		 * alldata.get(to)); System.out.println(test.getDistance());
		 * System.out.println();
		 * 
		 * 
		 * from = 18; to = 18;
		 * System.out.println(testDataRight.get(from).getX()+":"+testDataRight.
		 * get(from).getY());
		 * System.out.println(testDataRight.get(from).getX()+":"+testDataRight.
		 * get(from).getY());
		 * test.calculateDisPenaltyZero(testDataRight.get(from),
		 * testDataRight.get(from)); System.out.println(test.getDistance());
		 * System.out.println();
		 * 
		 * 
		 * //System.out.println("number of samplePoint "+testDataRight.size());
		 * //System.out.println("number of WifiSignals "+parts.length);
		 * 
		 */

	}

	// create test data right direction tablet
	public void testData3() {
		String content = "";
		try {
			content = readFile("RightDirectionTablet.txt", StandardCharsets.UTF_8);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		content = content.replace("\n", "").replace("\r", "");
		String[] parts = content.split(",");

		long lastTimeStamp = 0;
		int i = 0;
		SamplePoint lastSamplePoint = null;
		int sum = 0;
		int div = 0;
		while (i < parts.length) {
			int x = 0;
			int y = 0;

			if ((parts[i].toString().equals("-1.0"))) {
				x = -1;
			} else
				x = Integer.parseInt(parts[i].toString());
			i++;
			if ((parts[i].toString().equals("-1.0"))) {
				y = -1;
			} else
				y = Integer.parseInt(parts[i].toString());
			i++;
			// System.out.println(parts[i]);
			i++;
			String name = parts[i];
			// System.out.println(parts[i]);
			i++;
			int stregth = Integer.parseInt(parts[i]);
			// System.out.println(parts[i]);

			WifiPoint toAdd = new WifiPoint(name, stregth);
			Boolean contains = false;

			i++;

			long TimeStampNow = Long.parseLong(parts[i].toString());

			if (TimeStampNow != lastTimeStamp) {

				SamplePoint tempSamplePoint = new SamplePoint(x, y);
				// don't add if walking x = -1 equal walking
				if (x != -1)
					testDataTabletRight.add(tempSamplePoint);

				Boolean contains2 = false;

				for (WifiPoint temp : filter) {
					if (temp.getWifiname().toString().equals(toAdd.getWifiname())) {
						contains2 = true;
						temp.numberOfTimes++;
						break;
					}

				}

				// if a wifiname not is in the filter don't add it
				if (contains2 == true)

					tempSamplePoint.addWifiPoint(new WifiPoint(name, stregth));

				lastSamplePoint = tempSamplePoint;

			} else {
				lastSamplePoint.addWifiPoint(new WifiPoint(name, stregth));
			}

			lastTimeStamp = TimeStampNow;

			i++;
			// System.out.println(i);

		}

		// remove if there are samplePoint with the same x coordinate.
		int yy = 0;
		for (int tt = 0; tt < testDataTabletRight.size(); tt++) {

			if (tt != 0) {
				if ((testDataTabletRight.get(tt).getX() == testDataTabletRight.get(tt - 1).getX())
						&& (testDataTabletRight.get(tt).getY() == testDataTabletRight.get(tt - 1).getY())) {
					testDataTabletRight.remove(tt - 1);
				}
			}

		}

		// int ii = 0;
		// for (SamplePoint temp : alldata) {
		// System.out.println(temp.getX()+" "+temp.getY());
		// ii++;
		// System.out.println(ii+"dd");
		// }

		// System.out.println(alldata.get(10).getAllWifi());

		/*
		 * Euclidean test = new Euclidean();
		 * 
		 * 
		 * int from = 18; int to = 18;
		 * 
		 * System.out.println(testDataRight.get(from).getX()+":"+testDataRight.
		 * get(from).getY());
		 * System.out.println(alldata.get(to).getX()+":"+alldata.get(to).getY())
		 * ; test.calculateDisPenaltyZero(testDataRight.get(from),
		 * alldata.get(to)); System.out.println(test.getDistance());
		 * System.out.println();
		 * 
		 * from = 18; to = 45;
		 * 
		 * System.out.println(testDataRight.get(from).getX()+":"+testDataRight.
		 * get(from).getY());
		 * System.out.println(alldata.get(to).getX()+":"+alldata.get(to).getY())
		 * ; test.calculateDisPenaltyZero(testDataRight.get(from),
		 * alldata.get(to)); System.out.println(test.getDistance());
		 * System.out.println();
		 * 
		 * 
		 * from = 18; to = 18;
		 * System.out.println(testDataRight.get(from).getX()+":"+testDataRight.
		 * get(from).getY());
		 * System.out.println(testDataRight.get(from).getX()+":"+testDataRight.
		 * get(from).getY());
		 * test.calculateDisPenaltyZero(testDataRight.get(from),
		 * testDataRight.get(from)); System.out.println(test.getDistance());
		 * System.out.println();
		 * 
		 * 
		 * //System.out.println("number of samplePoint "+testDataRight.size());
		 * //System.out.println("number of WifiSignals "+parts.length);
		 * 
		 */

	}

	// ArrayList<SamplePoint> longRunData = new ArrayList();

	// create test data right direction tablet

	public ArrayList<SamplePoint> MakeLongRunDataSub(String filename) {

		ArrayList<SamplePoint> X2 = new ArrayList();

		String content = "";
		try {

			content = readFile(filename, StandardCharsets.UTF_8);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		content = content.replace("\n", "").replace("\r", "");
		String[] parts = content.split(",");

		long lastTimeStamp = 0;
		int i = 0;
		SamplePoint lastSamplePoint = null;
		int sum = 0;
		int div = 0;

		while (i < parts.length) {
			int x = 0;
			int y = 0;

			if ((parts[i].toString().equals("-1.0"))) {
				x = -1;
			} else
				x = Integer.parseInt(parts[i].toString());
			i++;
			if ((parts[i].toString().equals("-1.0"))) {
				y = -1;
			} else
				y = Integer.parseInt(parts[i].toString());
			i++;
			// System.out.println(parts[i]);
			i++;
			String name = parts[i];
			// System.out.println(parts[i]);
			i++;
			int stregth = Integer.parseInt(parts[i]);
			// System.out.println(parts[i]);

			WifiPoint toAdd = new WifiPoint(name, stregth);
			Boolean contains = false;

			i++;

			long TimeStampNow = Long.parseLong(parts[i].toString());

			if (TimeStampNow != lastTimeStamp) {

				SamplePoint tempSamplePoint = new SamplePoint(x, y);
				// don't add if walking x = -1 equal walking
				if (x != -1)
					X2.add(tempSamplePoint);

				Boolean contains2 = false;

				for (WifiPoint temp : filter) {
					if (temp.getWifiname().toString().equals(toAdd.getWifiname())) {
						contains2 = true;
						temp.numberOfTimes++;
						break;
					}

				}

				// if a wifiname not is in the filter don't add it
				if (contains2 == true)

					tempSamplePoint.addWifiPoint(new WifiPoint(name, stregth));

				lastSamplePoint = tempSamplePoint;

			} else {
				lastSamplePoint.addWifiPoint(new WifiPoint(name, stregth));
			}

			lastTimeStamp = TimeStampNow;

			i++;

		}

		int total = X2.size();

		int from = 0;
		double howmany = 475;
		double hh = new Double(total);
		double jump = (howmany / hh);
		jump = jump + 0.2;
		// System.out.println(jump+"jump");
		double numberOfTimes = 0;
		int now = from;
		for (SamplePoint temp : X2) {
			numberOfTimes++;

			int x = temp.getY();
			int y = temp.getX();

			// fix the problem with that x and y is switch
			temp.setX(x);
			temp.setY(y);
			temp.setX(now);

			now = (int) ((jump * numberOfTimes));

			// System.out.println(""+temp.getX()+" "+temp.getY());

		}
		// System.out.println(numberOfTimes+"numberOfTimes");
		// System.out.println(total+"total");
		return (X2);

	}

	public ArrayList<SamplePoint> MakeShortRunDataSubTo475(String filename) {

		ArrayList<SamplePoint> X2 = new ArrayList();

		String content = "";
		try {

			content = readFile(filename, StandardCharsets.UTF_8);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		content = content.replace("\n", "").replace("\r", "");
		String[] parts = content.split(",");

		long lastTimeStamp = 0;
		int i = 0;
		SamplePoint lastSamplePoint = null;
		int sum = 0;
		int div = 0;

		while (i < parts.length) {
			int x = 0;
			int y = 0;

			if ((parts[i].toString().equals("-1.0"))) {
				x = -1;
			} else
				x = Integer.parseInt(parts[i].toString());
			i++;
			if ((parts[i].toString().equals("-1.0"))) {
				y = -1;
			} else
				y = Integer.parseInt(parts[i].toString());
			i++;
			// System.out.println(parts[i]);
			i++;
			String name = parts[i];
			// System.out.println(parts[i]);
			i++;
			int stregth = Integer.parseInt(parts[i]);
			// System.out.println(parts[i]);

			WifiPoint toAdd = new WifiPoint(name, stregth);
			Boolean contains = false;

			i++;

			long TimeStampNow = Long.parseLong(parts[i].toString());

			if (TimeStampNow != lastTimeStamp) {

				SamplePoint tempSamplePoint = new SamplePoint(x, y);
				// don't add if walking x = -1 equal walking
				if (x != -1)
					X2.add(tempSamplePoint);

				Boolean contains2 = false;

				for (WifiPoint temp : filter) {
					if (temp.getWifiname().toString().equals(toAdd.getWifiname())) {
						contains2 = true;
						temp.numberOfTimes++;
						break;
					}

				}

				// if a wifiname not is in the filter don't add it
				if (contains2 == true)

					tempSamplePoint.addWifiPoint(new WifiPoint(name, stregth));

				lastSamplePoint = tempSamplePoint;

			} else {
				lastSamplePoint.addWifiPoint(new WifiPoint(name, stregth));
			}

			lastTimeStamp = TimeStampNow;

			i++;

		}

		int total = X2.size();
		// System.out.println("-------------------------------");
		int from = 239;
		double howmany = 475 - 239;
		double hh = new Double(total);
		double jump = (howmany / hh);
		jump = jump + 0.4;
		// System.out.println(jump+"jump");
		double numberOfTimes = 0;
		int now = from;

		for (SamplePoint temp : X2) {
			numberOfTimes++;

			int x = temp.getY();
			int y = temp.getX();

			// fix the problem with that x and y is switch
			temp.setX(x);
			temp.setY(y);
			// System.out.println("--"+now+"--");
			temp.setX(now);

			now = (int) (from + (jump * numberOfTimes));

			// System.out.println(""+temp.getX()+" "+temp.getY());

		}
		// System.out.println(numberOfTimes+"numberOfTimes");
		// System.out.println(total+"total");
		return (X2);

	}

	public ArrayList<SamplePoint> MakeShortRunDataSubTo239(String filename) {

		ArrayList<SamplePoint> X2 = new ArrayList();

		String content = "";
		try {

			content = readFile(filename, StandardCharsets.UTF_8);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		content = content.replace("\n", "").replace("\r", "");
		String[] parts = content.split(",");

		long lastTimeStamp = 0;
		int i = 0;
		SamplePoint lastSamplePoint = null;
		int sum = 0;
		int div = 0;

		while (i < parts.length) {
			int x = 0;
			int y = 0;

			if ((parts[i].toString().equals("-1.0"))) {
				x = -1;
			} else
				x = Integer.parseInt(parts[i].toString());
			i++;
			if ((parts[i].toString().equals("-1.0"))) {
				y = -1;
			} else
				y = Integer.parseInt(parts[i].toString());
			i++;
			// System.out.println(parts[i]);
			i++;
			String name = parts[i];
			// System.out.println(parts[i]);
			i++;
			int stregth = Integer.parseInt(parts[i]);
			// System.out.println(parts[i]);

			WifiPoint toAdd = new WifiPoint(name, stregth);
			Boolean contains = false;

			i++;

			long TimeStampNow = Long.parseLong(parts[i].toString());

			if (TimeStampNow != lastTimeStamp) {

				SamplePoint tempSamplePoint = new SamplePoint(x, y);
				// don't add if walking x = -1 equal walking
				if (x != -1)
					X2.add(tempSamplePoint);

				Boolean contains2 = false;

				for (WifiPoint temp : filter) {
					if (temp.getWifiname().toString().equals(toAdd.getWifiname())) {
						contains2 = true;
						temp.numberOfTimes++;
						break;
					}

				}

				// if a wifiname not is in the filter don't add it
				if (contains2 == true)

					tempSamplePoint.addWifiPoint(new WifiPoint(name, stregth));

				lastSamplePoint = tempSamplePoint;

			} else {
				lastSamplePoint.addWifiPoint(new WifiPoint(name, stregth));
			}

			lastTimeStamp = TimeStampNow;

			i++;

		}

		int total = X2.size();

		int from = 0;
		double howmany = 239;
		double hh = new Double(total);
		double jump = (howmany / hh);
		jump = jump + 0.3;
		// System.out.println(jump+"jump");
		double numberOfTimes = 0;
		int now = from;
		for (SamplePoint temp : X2) {
			numberOfTimes++;

			int x = temp.getY();
			int y = temp.getX();

			// fix the problem with that x and y is switch
			temp.setX(x);
			temp.setY(y);
			temp.setX(now);

			now = (int) ((jump * numberOfTimes));

			// System.out.println(""+temp.getX()+" "+temp.getY());

		}
		// System.out.println(numberOfTimes+"numberOfTimes");
		// System.out.println(total+"total");
		return (X2);

	}

	private int round(double d) {
		double dAbs = Math.abs(d);
		int i = (int) dAbs;
		double result = dAbs - (double) i;
		if (result < 0.5) {
			return d < 0 ? -i : i;
		} else {
			return d < 0 ? -(i + 1) : i + 1;
		}
	}

	public void calculateEuclideanToLongRunRightDirection(int median, int penalty, boolean dis) {

		// testdata right direction against offelineMappAll
		ArrayList<Euclidean> Eu1 = new ArrayList();
		int errorsum = 0;
		int[] errorUnder = new int[11];
		int numberOfTimes = 0;

		for (SamplePoint temp : testDataRight) {

			Eu1.clear();
			SamplePoint tempq = temp;

			for (SamplePoint temp2 : longRunData) {

				Euclidean insert = new Euclidean();

				if (penalty == 1)
					insert.calculateDisPenaltyZero(tempq, temp2);
				if (penalty == 2)
					insert.calculateDisPenaltyHundred(tempq, temp2);
				if (penalty == 3)
					insert.calculateDisAllThere(tempq, temp2);

				Eu1.add(insert);

			}

			// }
			// System.out.println(Eu1.size()+"size");
			// System.out.println(Eu1.get(1).getDistance());
			Collections.sort(Eu1);
			// System.out.println(Eu1.get(1).getDistance());

			// System.out.println();

			// System.out.println("From "+ temp.getX()+":"+temp.getY());
			// System.out.println("from
			// "+Eu1.get(1).getSampleA().getX()+":"+Eu1.get(1).getSampleA().getY());
			// System.out.println("to
			// "+Eu1.get(0).getSampleB().getX()+":"+Eu1.get(0).getSampleB().getY());
			// System.out.println("distance "+Eu1.get(0).getDistance());
			// System.out.println("distance in cm =
			// "+distanceInCm(testDataRight.get(1),Eu1.get(0).getSampleB()));

			int x = 0;
			int y = 0;

			for (int i = 0; i < median; i++) {
				x = x + Eu1.get(i).getSampleB().getX();
				y = y + Eu1.get(i).getSampleB().getY();
				// System.out.println("-------"+i);

			}

			x = x / median;
			y = y / median;

			// System.out.println("distance gennesmit cm=
			// "+distanceInCm(tempq,x,y));

			int distance = distanceInCm(tempq, x, y);
			errorsum = errorsum + distance;

			numberOfTimes++;
			if (distance < 100) {
				errorUnder[1]++;
			}
			if (distance < 200) {
				errorUnder[2]++;
			}
			if (distance < 300) {
				errorUnder[3]++;
			}
			if (distance < 400) {
				errorUnder[4]++;
			}
			if (distance < 500) {
				errorUnder[5]++;
			}
			if (distance < 600) {
				errorUnder[6]++;
			}
			if (distance < 700) {
				errorUnder[7]++;
			}
			if (distance < 800) {
				errorUnder[8]++;
			}
			if (distance < 900) {
				errorUnder[9]++;
			}
			if (distance < 1000) {
				errorUnder[10]++;
			}

			// System.out.println("from "+tempq.getX()+" "+tempq.getY());
			// System.out.println("to "+x+" "+y);
		}

		double errorSumMedian = errorsum / testDataRight.size();

		if (dis) {

			int all = numberOfTimes;

			System.out.println((((errorUnder[1] * 100 / all))) + "%," + 100);
			System.out.println((((errorUnder[2] * 100 / all))) + "%," + 200);
			System.out.println((((errorUnder[3] * 100 / all))) + "%," + 300);
			System.out.println((((errorUnder[4] * 100 / all))) + "%," + 400);
			System.out.println((((errorUnder[5] * 100 / all))) + "%," + 500);
			System.out.println((((errorUnder[6] * 100 / all))) + "%," + 600);
			System.out.println((((errorUnder[7] * 100 / all))) + "%," + 700);
			System.out.println((((errorUnder[8] * 100 / all))) + "%," + 800);
			System.out.println((((errorUnder[9] * 100 / all))) + "%," + 900);
			System.out.println((((errorUnder[10] * 100 / all))) + "%," + 1000);

		} else {
			System.out.println("");
			System.out.println("longRun right");
			System.out.println("error sum median:" + errorSumMedian);
		}
	}

	public void calculateEuclideanToShortRunRightDirection(int median, int penalty, boolean dis) {

		// testdata right direction against offelineMappAll
		ArrayList<Euclidean> Eu1 = new ArrayList();
		int errorsum = 0;
		int[] errorUnder = new int[11];
		int numberOfTimes = 0;

		for (SamplePoint temp : testDataRight) {

			Eu1.clear();
			SamplePoint tempq = temp;

			for (SamplePoint temp2 : shortRunData) {

				Euclidean insert = new Euclidean();

				if (penalty == 1)
					insert.calculateDisPenaltyZero(tempq, temp2);
				if (penalty == 2)
					insert.calculateDisPenaltyHundred(tempq, temp2);
				if (penalty == 3)
					insert.calculateDisAllThere(tempq, temp2);

				Eu1.add(insert);

			}

			// }
			// System.out.println(Eu1.size()+"size");
			// System.out.println(Eu1.get(1).getDistance());
			Collections.sort(Eu1);
			// System.out.println(Eu1.get(1).getDistance());

			// System.out.println();

			// System.out.println("From "+ temp.getX()+":"+temp.getY());
			// System.out.println("from
			// "+Eu1.get(1).getSampleA().getX()+":"+Eu1.get(1).getSampleA().getY());
			// System.out.println("to
			// "+Eu1.get(0).getSampleB().getX()+":"+Eu1.get(0).getSampleB().getY());
			// System.out.println("distance "+Eu1.get(0).getDistance());
			// System.out.println("distance in cm =
			// "+distanceInCm(testDataRight.get(1),Eu1.get(0).getSampleB()));

			int x = 0;
			int y = 0;

			for (int i = 0; i < median; i++) {
				x = x + Eu1.get(i).getSampleB().getX();
				y = y + Eu1.get(i).getSampleB().getY();
				// System.out.println("-------"+i);

			}

			x = x / median;
			y = y / median;

			// System.out.println("distance gennesmit cm=
			// "+distanceInCm(tempq,x,y));

			int distance = distanceInCm(tempq, x, y);
			errorsum = errorsum + distance;

			numberOfTimes++;
			if (distance < 100) {
				errorUnder[1]++;
			}
			if (distance < 200) {
				errorUnder[2]++;
			}
			if (distance < 300) {
				errorUnder[3]++;
			}
			if (distance < 400) {
				errorUnder[4]++;
			}
			if (distance < 500) {
				errorUnder[5]++;
			}
			if (distance < 600) {
				errorUnder[6]++;
			}
			if (distance < 700) {
				errorUnder[7]++;
			}
			if (distance < 800) {
				errorUnder[8]++;
			}
			if (distance < 900) {
				errorUnder[9]++;
			}
			if (distance < 1000) {
				errorUnder[10]++;
			}

			// System.out.println("from "+tempq.getX()+" "+tempq.getY());
			// System.out.println("to "+x+" "+y);
		}

		double errorSumMedian = errorsum / testDataRight.size();

		if (dis) {

			int all = numberOfTimes;

			System.out.println((((errorUnder[1] * 100 / all))) + "%," + 100);
			System.out.println((((errorUnder[2] * 100 / all))) + "%," + 200);
			System.out.println((((errorUnder[3] * 100 / all))) + "%," + 300);
			System.out.println((((errorUnder[4] * 100 / all))) + "%," + 400);
			System.out.println((((errorUnder[5] * 100 / all))) + "%," + 500);
			System.out.println((((errorUnder[6] * 100 / all))) + "%," + 600);
			System.out.println((((errorUnder[7] * 100 / all))) + "%," + 700);
			System.out.println((((errorUnder[8] * 100 / all))) + "%," + 800);
			System.out.println((((errorUnder[9] * 100 / all))) + "%," + 900);
			System.out.println((((errorUnder[10] * 100 / all))) + "%," + 1000);

		} else {
			System.out.println("");
			System.out.println("shortRun right");
			System.out.println("error sum median:" + errorSumMedian);
		}
	}

	public void calculateEuclideanToLongRunDoppelDataRightDirection(int median, int penalty, boolean dis) {

		// testdata right direction against offelineMappAll
		ArrayList<Euclidean> Eu1 = new ArrayList();
		int errorsum = 0;
		int[] errorUnder = new int[11];
		int numberOfTimes = 0;

		for (SamplePoint temp : testDataRight) {

			Eu1.clear();
			SamplePoint tempq = temp;

			for (SamplePoint temp2 : longRunData2) {

				Euclidean insert = new Euclidean();

				if (penalty == 1)
					insert.calculateDisPenaltyZero(tempq, temp2);
				if (penalty == 2)
					insert.calculateDisPenaltyHundred(tempq, temp2);
				if (penalty == 3)
					insert.calculateDisAllThere(tempq, temp2);

				Eu1.add(insert);

			}

			// }
			// System.out.println(Eu1.size()+"size");
			// System.out.println(Eu1.get(1).getDistance());
			Collections.sort(Eu1);
			// System.out.println(Eu1.get(1).getDistance());

			// System.out.println();

			// System.out.println("From "+ temp.getX()+":"+temp.getY());
			// System.out.println("from
			// "+Eu1.get(1).getSampleA().getX()+":"+Eu1.get(1).getSampleA().getY());
			// System.out.println("to
			// "+Eu1.get(0).getSampleB().getX()+":"+Eu1.get(0).getSampleB().getY());
			// System.out.println("distance "+Eu1.get(0).getDistance());
			// System.out.println("distance in cm =
			// "+distanceInCm(testDataRight.get(1),Eu1.get(0).getSampleB()));

			int x = 0;
			int y = 0;

			for (int i = 0; i < median; i++) {
				x = x + Eu1.get(i).getSampleB().getX();
				y = y + Eu1.get(i).getSampleB().getY();
				// System.out.println("-------"+i);

			}

			x = x / median;
			y = y / median;

			// System.out.println("distance gennesmit cm=
			// "+distanceInCm(tempq,x,y));

			int distance = distanceInCm(tempq, x, y);
			errorsum = errorsum + distance;

			numberOfTimes++;
			if (distance < 100) {
				errorUnder[1]++;
			}
			if (distance < 200) {
				errorUnder[2]++;
			}
			if (distance < 300) {
				errorUnder[3]++;
			}
			if (distance < 400) {
				errorUnder[4]++;
			}
			if (distance < 500) {
				errorUnder[5]++;
			}
			if (distance < 600) {
				errorUnder[6]++;
			}
			if (distance < 700) {
				errorUnder[7]++;
			}
			if (distance < 800) {
				errorUnder[8]++;
			}
			if (distance < 900) {
				errorUnder[9]++;
			}
			if (distance < 1000) {
				errorUnder[10]++;
			}

			// System.out.println("from "+tempq.getX()+" "+tempq.getY());
			// System.out.println("to "+x+" "+y);
		}

		double errorSumMedian = errorsum / testDataRight.size();

		if (dis) {

			int all = numberOfTimes;

			System.out.println((((errorUnder[1] * 100 / all))) + "%," + 100);
			System.out.println((((errorUnder[2] * 100 / all))) + "%," + 200);
			System.out.println((((errorUnder[3] * 100 / all))) + "%," + 300);
			System.out.println((((errorUnder[4] * 100 / all))) + "%," + 400);
			System.out.println((((errorUnder[5] * 100 / all))) + "%," + 500);
			System.out.println((((errorUnder[6] * 100 / all))) + "%," + 600);
			System.out.println((((errorUnder[7] * 100 / all))) + "%," + 700);
			System.out.println((((errorUnder[8] * 100 / all))) + "%," + 800);
			System.out.println((((errorUnder[9] * 100 / all))) + "%," + 900);
			System.out.println((((errorUnder[10] * 100 / all))) + "%," + 1000);

		} else {
			System.out.println("");
			System.out.println("longRun doppel data right");
			System.out.println("error sum median:" + errorSumMedian);
		}
	}

	public void calculateEuclideanToAllRightDirection(int median, int penalty, boolean dis) {

		// testdata right direction against offelineMappAll
		ArrayList<Euclidean> Eu1 = new ArrayList();
		int errorsum = 0;
		int[] errorUnder = new int[11];
		int numberOfTimes = 0;

		for (SamplePoint temp : testDataRight) {

			Eu1.clear();
			SamplePoint tempq = temp;

			for (SamplePoint temp2 : alldata) {

				Euclidean insert = new Euclidean();

				if (penalty == 1)
					insert.calculateDisPenaltyZero(tempq, temp2);
				if (penalty == 2)
					insert.calculateDisPenaltyHundred(tempq, temp2);
				if (penalty == 3)
					insert.calculateDisAllThere(tempq, temp2);

				Eu1.add(insert);

			}

			// }
			// System.out.println(Eu1.size()+"size");
			// System.out.println(Eu1.get(1).getDistance());
			Collections.sort(Eu1);
			// System.out.println(Eu1.get(1).getDistance());

			// System.out.println();

			// System.out.println("From "+
			// testDataRight.get(1).getX()+":"+testDataRight.get(1).getY());
			// System.out.println("from
			// "+Eu1.get(1).getSampleA().getX()+":"+Eu1.get(1).getSampleA().getY());
			// System.out.println("to
			// "+Eu1.get(1).getSampleB().getX()+":"+Eu1.get(1).getSampleB().getY());
			// System.out.println("distance "+Eu1.get(0).getDistance());
			// System.out.println("distance in cm =
			// "+distanceInCm(testDataRight.get(1),Eu1.get(0).getSampleB()));

			int x = 0;
			int y = 0;

			for (int i = 0; i < median; i++) {
				x = x + Eu1.get(i).getSampleB().getX();
				y = y + Eu1.get(i).getSampleB().getY();
				// System.out.println("-------"+i);

			}

			x = x / median;
			y = y / median;

			// System.out.println("distance gennesmit cm=
			// "+distanceInCm(tempq,x,y));

			int distance = distanceInCm(tempq, x, y);
			errorsum = errorsum + distance;

			numberOfTimes++;
			if (distance < 100) {
				errorUnder[1]++;
			}
			if (distance < 200) {
				errorUnder[2]++;
			}
			if (distance < 300) {
				errorUnder[3]++;
			}
			if (distance < 400) {
				errorUnder[4]++;
			}
			if (distance < 500) {
				errorUnder[5]++;
			}
			if (distance < 600) {
				errorUnder[6]++;
			}
			if (distance < 700) {
				errorUnder[7]++;
			}
			if (distance < 800) {
				errorUnder[8]++;
			}
			if (distance < 900) {
				errorUnder[9]++;
			}
			if (distance < 1000) {
				errorUnder[10]++;
			}

			// System.out.println("from "+tempq.getX()+" "+tempq.getY());
			// System.out.println("to "+x+" "+y);
		}

		double errorSumMedian = errorsum / testDataRight.size();

		if (dis) {

			int all = numberOfTimes;

			System.out.println((((errorUnder[1] * 100 / all))) + "%," + 100);
			System.out.println((((errorUnder[2] * 100 / all))) + "%," + 200);
			System.out.println((((errorUnder[3] * 100 / all))) + "%," + 300);
			System.out.println((((errorUnder[4] * 100 / all))) + "%," + 400);
			System.out.println((((errorUnder[5] * 100 / all))) + "%," + 500);
			System.out.println((((errorUnder[6] * 100 / all))) + "%," + 600);
			System.out.println((((errorUnder[7] * 100 / all))) + "%," + 700);
			System.out.println((((errorUnder[8] * 100 / all))) + "%," + 800);
			System.out.println((((errorUnder[9] * 100 / all))) + "%," + 900);
			System.out.println((((errorUnder[10] * 100 / all))) + "%," + 1000);

		} else {
			System.out.println("");
			System.out.println("right");
			System.out.println("error sum median:" + errorSumMedian);
		}
	}

	public void calculateEuclideanToAllRightDirectionTablet(int median, int penalty, boolean dis) {

		// testdata right direction against offelineMappAll
		ArrayList<Euclidean> Eu1 = new ArrayList();
		int errorsum = 0;
		int[] errorUnder = new int[11];
		int numberOfTimes = 0;

		for (SamplePoint temp : testDataTabletRight) {

			Eu1.clear();
			SamplePoint tempq = temp;

			for (SamplePoint temp2 : alldata) {

				Euclidean insert = new Euclidean();
				if (penalty == 1)
					insert.calculateDisPenaltyZero(tempq, temp2);
				if (penalty == 2)
					insert.calculateDisPenaltyHundred(tempq, temp2);
				if (penalty == 3)
					insert.calculateDisAllThere(tempq, temp2);

				Eu1.add(insert);

			}

			// }
			// System.out.println(Eu1.size()+"size");
			// System.out.println(Eu1.get(1).getDistance());
			Collections.sort(Eu1);
			// System.out.println(Eu1.get(1).getDistance());

			// System.out.println();

			// System.out.println("From "+
			// testDataRight.get(1).getX()+":"+testDataRight.get(1).getY());
			// System.out.println("from
			// "+Eu1.get(1).getSampleA().getX()+":"+Eu1.get(1).getSampleA().getY());
			// System.out.println("to
			// "+Eu1.get(1).getSampleB().getX()+":"+Eu1.get(1).getSampleB().getY());
			// System.out.println("distance "+Eu1.get(0).getDistance());
			// System.out.println("distance in cm =
			// "+distanceInCm(testDataRight.get(1),Eu1.get(0).getSampleB()));

			int x = 0;
			int y = 0;
			for (int i = 0; i < median; i++) {
				x = x + Eu1.get(i).getSampleB().getX();
				y = y + Eu1.get(i).getSampleB().getY();
				// System.out.println("-------"+i);

			}

			x = x / median;
			y = y / median;

			// System.out.println("distance gennesmit cm=
			// "+distanceInCm(tempq,x,y));
			int distance = distanceInCm(tempq, x, y);

			errorsum = errorsum + distance;

			// System.out.println("from "+tempq.getX()+" "+tempq.getY());
			// System.out.println("to "+x+" "+y);

			numberOfTimes++;
			if (distance < 100) {
				errorUnder[1]++;
			}
			if (distance < 200) {
				errorUnder[2]++;
			}
			if (distance < 300) {
				errorUnder[3]++;
			}
			if (distance < 400) {
				errorUnder[4]++;
			}
			if (distance < 500) {
				errorUnder[5]++;
			}
			if (distance < 600) {
				errorUnder[6]++;
			}
			if (distance < 700) {
				errorUnder[7]++;
			}
			if (distance < 800) {
				errorUnder[8]++;
			}
			if (distance < 900) {
				errorUnder[9]++;
			}
			if (distance < 1000) {
				errorUnder[10]++;
			}
		}

		double errorSumMedian = errorsum / testDataTabletRight.size();

		if (dis) {

			int all = numberOfTimes;

			System.out.println((((errorUnder[1] * 100 / all))) + "%," + 100);
			System.out.println((((errorUnder[2] * 100 / all))) + "%," + 200);
			System.out.println((((errorUnder[3] * 100 / all))) + "%," + 300);
			System.out.println((((errorUnder[4] * 100 / all))) + "%," + 400);
			System.out.println((((errorUnder[5] * 100 / all))) + "%," + 500);
			System.out.println((((errorUnder[6] * 100 / all))) + "%," + 600);
			System.out.println((((errorUnder[7] * 100 / all))) + "%," + 700);
			System.out.println((((errorUnder[8] * 100 / all))) + "%," + 800);
			System.out.println((((errorUnder[9] * 100 / all))) + "%," + 900);
			System.out.println((((errorUnder[10] * 100 / all))) + "%," + 1000);

		} else {
			System.out.println("");
			System.out.println("tablet right");
			System.out.println("error sum :" + errorSumMedian);
		}

	}

	public void calculateEuclideanToAllWrongDirection(int median, int penalty, boolean dis) {

		// testdata right direction against offelineMappAll
		ArrayList<Euclidean> Eu1 = new ArrayList();
		int errorsum = 0;
		int[] errorUnder = new int[11];
		int numberOfTimes = 0;

		for (SamplePoint temp : testDataWrong) {

			Eu1.clear();
			SamplePoint tempq = temp;

			for (SamplePoint temp2 : alldata) {

				Euclidean insert = new Euclidean();
				if (penalty == 1)
					insert.calculateDisPenaltyZero(tempq, temp2);
				if (penalty == 2)
					insert.calculateDisPenaltyHundred(tempq, temp2);
				if (penalty == 3)
					insert.calculateDisAllThere(tempq, temp2);

				Eu1.add(insert);

			}

			Collections.sort(Eu1);

			int x = 0;
			int y = 0;
			for (int i = 0; i < median; i++) {
				x = x + Eu1.get(i).getSampleB().getX();
				y = y + Eu1.get(i).getSampleB().getY();

			}

			x = x / median;
			y = y / median;

			int distance = distanceInCm(tempq, x, y);

			errorsum = errorsum + distance;

			numberOfTimes++;
			if (distance < 100) {
				errorUnder[1]++;
			}
			if (distance < 200) {
				errorUnder[2]++;
			}
			if (distance < 300) {
				errorUnder[3]++;
			}
			if (distance < 400) {
				errorUnder[4]++;
			}
			if (distance < 500) {
				errorUnder[5]++;
			}
			if (distance < 600) {
				errorUnder[6]++;
			}
			if (distance < 700) {
				errorUnder[7]++;
			}
			if (distance < 800) {
				errorUnder[8]++;
			}
			if (distance < 900) {
				errorUnder[9]++;
			}
			if (distance < 1000) {
				errorUnder[10]++;
			}

		}

		double errorSumMedian = errorsum / testDataWrong.size();

		if (dis) {

			int all = numberOfTimes;

			System.out.println((((errorUnder[1] * 100 / all))) + "%," + 100);
			System.out.println((((errorUnder[2] * 100 / all))) + "%," + 200);
			System.out.println((((errorUnder[3] * 100 / all))) + "%," + 300);
			System.out.println((((errorUnder[4] * 100 / all))) + "%," + 400);
			System.out.println((((errorUnder[5] * 100 / all))) + "%," + 500);
			System.out.println((((errorUnder[6] * 100 / all))) + "%," + 600);
			System.out.println((((errorUnder[7] * 100 / all))) + "%," + 700);
			System.out.println((((errorUnder[8] * 100 / all))) + "%," + 800);
			System.out.println((((errorUnder[9] * 100 / all))) + "%," + 900);
			System.out.println((((errorUnder[10] * 100 / all))) + "%," + 1000);

		} else {
			System.out.println("");
			System.out.println("wrong direction");
			System.out.println("error sum :" + errorSumMedian);
		}

	}

	public int distanceInCm(SamplePoint from, int tx, int ty) {
		int result = 0;

		double t = Math.sqrt(((Math.pow(((from.getX()) - (tx)), 2)) + (Math.pow(((from.getY()) - (ty)), 2))));

		// 1 unit is 30 cm
		t = t * 30;

		return (int) t;

	}

	public int distanceInCm(SamplePoint from, SamplePoint to) {
		int result = 0;

		double t = Math
				.sqrt(((Math.pow(((from.getX()) - (to.getX())), 2)) + (Math.pow(((from.getY()) - (to.getY())), 2))));

		// 1 unit is 30 cm
		t = t * 30;

		return (int) t;

	}

	public void MakeLongRunData() {
		ArrayList<SamplePoint> X2 = new ArrayList();
		ArrayList<SamplePoint> X6 = new ArrayList();
		ArrayList<SamplePoint> X10 = new ArrayList();
		ArrayList<SamplePoint> X14 = new ArrayList();

		X2 = MakeLongRunDataSub("longRunX2.txt");
		X6 = MakeLongRunDataSub("longRunX6.txt");
		X10 = MakeLongRunDataSub("longRunX10.txt");
		X14 = MakeLongRunDataSub("longRunX14.txt");

		for (SamplePoint temp : X2) {

			longRunData.add(temp);
			// System.out.println(temp.getX()+":"+temp.getY());
		}

		for (SamplePoint temp : X6) {

			longRunData.add(temp);
		}

		for (SamplePoint temp : X10) {

			longRunData.add(temp);
		}

		for (SamplePoint temp : X14) {

			longRunData.add(temp);
		}

	}

	public void MakeShortRunData() {
		ArrayList<SamplePoint> X2 = new ArrayList();
		ArrayList<SamplePoint> X22 = new ArrayList();

		ArrayList<SamplePoint> X6 = new ArrayList();
		ArrayList<SamplePoint> X62 = new ArrayList();
		ArrayList<SamplePoint> X10 = new ArrayList();
		ArrayList<SamplePoint> X102 = new ArrayList();
		ArrayList<SamplePoint> X14 = new ArrayList();
		ArrayList<SamplePoint> X142 = new ArrayList();

		X2 = MakeShortRunDataSubTo239("shortRunX2.txt");
		X22 = MakeShortRunDataSubTo475("shortRunX22.txt");

		X6 = MakeShortRunDataSubTo239("shortRunX6.txt");
		X62 = MakeShortRunDataSubTo475("shortRunX62.txt");
		X10 = MakeShortRunDataSubTo239("shortRunX10.txt");
		X102 = MakeShortRunDataSubTo475("shortRunX102.txt");
		X14 = MakeShortRunDataSubTo239("shortRunX14.txt");
		X142 = MakeShortRunDataSubTo475("shortRunX142.txt");

		for (SamplePoint temp : X2) {

			shortRunData.add(temp);
			// System.out.println(temp.getX()+":"+temp.getY());
		}

		for (SamplePoint temp : X22) {

			shortRunData.add(temp);
			// System.out.println(temp.getX()+":"+temp.getY());
		}

		for (SamplePoint temp : X6) {

			shortRunData.add(temp);
			// System.out.println(temp.getX()+":"+temp.getY());
		}

		for (SamplePoint temp : X62) {

			shortRunData.add(temp);
			// System.out.println(temp.getX()+":"+temp.getY());
		}

		for (SamplePoint temp : X10) {

			shortRunData.add(temp);
			// System.out.println(temp.getX()+":"+temp.getY());
		}

		for (SamplePoint temp : X102) {

			shortRunData.add(temp);
			// System.out.println(temp.getX()+":"+temp.getY());
		}

		for (SamplePoint temp : X14) {

			shortRunData.add(temp);
			// System.out.println(temp.getX()+":"+temp.getY());
		}

		for (SamplePoint temp : X142) {

			shortRunData.add(temp);
			// System.out.println(temp.getX()+":"+temp.getY());
		}

	}

	public void MakeLongRunDataDoppelData() {
		ArrayList<SamplePoint> X2 = new ArrayList();
		ArrayList<SamplePoint> X6 = new ArrayList();
		ArrayList<SamplePoint> X10 = new ArrayList();
		ArrayList<SamplePoint> X14 = new ArrayList();

		X2 = MakeLongRunDataSub("longRunX2.txt");
		X6 = MakeLongRunDataSub("longRunX6.txt");
		X10 = MakeLongRunDataSub("longRunX10.txt");
		X14 = MakeLongRunDataSub("longRunX14.txt");

		ArrayList<SamplePoint> X22 = new ArrayList();
		ArrayList<SamplePoint> X62 = new ArrayList();
		ArrayList<SamplePoint> X102 = new ArrayList();
		ArrayList<SamplePoint> X142 = new ArrayList();

		X22 = MakeLongRunDataSub("longRunX22.txt");
		X62 = MakeLongRunDataSub("longRunX62.txt");
		X102 = MakeLongRunDataSub("longRunX102.txt");
		X142 = MakeLongRunDataSub("longRunX142.txt");

		for (SamplePoint temp : X2) {

			longRunData2.add(temp);
			// System.out.println(temp.getX()+":"+temp.getY());
		}

		for (SamplePoint temp : X6) {

			longRunData2.add(temp);
		}

		for (SamplePoint temp : X10) {

			longRunData2.add(temp);
		}

		for (SamplePoint temp : X14) {

			longRunData2.add(temp);
		}

		for (SamplePoint temp : X22) {

			longRunData2.add(temp);
			// System.out.println(temp.getX()+":"+temp.getY());
		}

		for (SamplePoint temp : X62) {

			longRunData2.add(temp);
		}

		for (SamplePoint temp : X102) {

			longRunData2.add(temp);
		}

		for (SamplePoint temp : X142) {

			longRunData2.add(temp);
		}

		// System.out.println("longRunData"+longRunData.size());

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ProcessData s = new ProcessData();
		s.createFilter();
		// s.offline1();
		// s.sameSpot();
		s.createFingerPrint();
		s.testData1();
		s.testData2();
		s.testData3();
		s.MakeLongRunData();
		s.MakeLongRunDataDoppelData();
		s.MakeShortRunData();

		/*
		 * first paramter median number of point 1 = one point
		 * 
		 * 1 = penalty 0 2 = penalty 100 3 = 75 % there
		 * 
		 * true/false error sum or distribution function data
		 */
		/*
		 * int fast = 19; s.calculateEuclideanToAllRightDirection(fast,1,false);
		 * s.calculateEuclideanToAllRightDirection(fast,2,false);
		 * s.calculateEuclideanToAllRightDirection(fast,3,false);
		 * s.calculateEuclideanToAllRightDirection(10,2,false);
		 * s.calculateEuclideanToAllWrongDirection(10,2,false);
		 * s.calculateEuclideanToAllRightDirectionTablet(10,2,true);
		 * s.calculateEuclideanToLongRunRightDirection(10, 2, false);
		 * s.calculateEuclideanToLongRunDoppelDataRightDirection(10, 2, true);
		 * 
		 */
		s.calculateEuclideanToShortRunRightDirection(5, 2, true);
		


	}

}
