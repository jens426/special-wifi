
public class WifiPoint {

	private String wifiname = "";
	private int stregth = 0;
	public int numberOfTimes = 0;

	public WifiPoint(String wifiname, int stregth) {
		this.wifiname = wifiname;
		this.stregth = stregth;

	}

	public String getWifiname() {
		return wifiname;
	}

	public void setWifiname(String wifiname) {
		this.wifiname = wifiname;
	}

	public int getStregth() {
		return stregth;
	}

	public void setStregth(int stregth) {
		this.stregth = stregth;
	}

	public String toString() {
		return wifiname;
	}

}
