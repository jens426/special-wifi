import java.util.ArrayList;

public class SamplePoint {

	private int x;
	private int y;
	ArrayList<WifiPoint> allWifiPoints = new ArrayList();

	public SamplePoint(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public ArrayList<WifiPoint> getAllWifi() {

		return allWifiPoints;
	}

	public int getWifiStregth(String navn) {

		for (WifiPoint temp : allWifiPoints) {

			if (temp.getWifiname().toString().equals(navn))
				return temp.getStregth();

		}

		return -999999;

	}

	public void addWifiPoint(WifiPoint temp) {
		allWifiPoints.add(temp);

	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

}
