package com.example.gui;

public class Point {

	private double x;
	private double y;
	private String bssid = "";
	private int dbm = 0;
	private long timestamp;

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	private boolean walking = false;

	public String getBssid() {
		return bssid;
	}

	public void setBssid(String bssid) {
		this.bssid = bssid;
	}

	public int getDbm() {
		return dbm;
	}

	public void setDbm(int dbm) {
		this.dbm = dbm;
	}

	public double getX() {
		return x;
	}

	public boolean getWalking() {
		return walking;
	}

	public void SetWalking(boolean walkingP) {
		walking = walkingP;

	}

	/*
	 * public void setX(double x) { this.x = x; }
	 */
	public double getY() {
		return y;
	}

	/*
	 * public void setY(double y) { this.y = y; }
	 * 
	 */
	public Point(double x, double y) {
		this.y = y;
		this.x = x;

	}

}
