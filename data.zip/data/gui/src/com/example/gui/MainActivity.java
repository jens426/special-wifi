package com.example.gui;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity {

	WifiManager mainWifi;
	WifiReceiver receiverWifi;
	List<ScanResult> wifiList;
	StringBuilder sb = new StringBuilder();
	BluetoothAdapter mBluetoothAdapter;

	static int positionX = -1;
	static int positionY = -1;
	static boolean wifiStop = false;
	// static ArrayList<Point> result = new ArrayList();
	static String resultString = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mainWifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
		receiverWifi = new WifiReceiver();
		registerReceiver(receiverWifi, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));

		// registerReceiver(receiverWifi, new IntentFilter());
		// mainWifi.startScan();

		Log.w("myApp", "\\nProgram started");

		mainWifi.disconnect();

		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		mBluetoothAdapter.startDiscovery();
		IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
		filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
		registerReceiver(mReceiver, filter);

		mBluetoothAdapter.cancelDiscovery();

	}

	int btime = 0;
	long bstart = 0;
	long bend = 0;

	ArrayList<BluetoothDevice> newDevices = new ArrayList();
	ArrayList<Integer> signalStre = new ArrayList();

	private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {

			String action = intent.getAction();
			// When discovery finds a device
			if (BluetoothDevice.ACTION_FOUND.equals(action)) {
				// Get the BluetoothDevice object from the Intent
				BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
				int rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE);

				// Log.w("myApp", "found bluetooth");
				if (!newDevices.contains(device)) {
					newDevices.add(device);
					signalStre.add(rssi);
				}
			} else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
				Log.w("myApp", "+++++++++++++++++++++++++++++++ " + btime);
				btime++;
				if (btime == 1)
					bstart = System.currentTimeMillis();

				if (btime < 4) {
					mBluetoothAdapter.startDiscovery();

				} else {
					bend = System.currentTimeMillis();
					long btimeresult = bend - bstart;

					Log.w("myApp", "time ---------------------: " + btimeresult);

				}

				Log.v("myApp", "discovery Finished ");
				if (newDevices.size() != 0) {
					// deviceList.invalidateViews();
					// sectionAdapter.notifyDataSetChanged();
					for (int i = 0; i < newDevices.size(); i++) {

						Log.w("myApp", newDevices.get(i).getAddress() + " " + signalStre.get(i));

					}
					Log.w("myApp", "----------------------------------");
					newDevices.clear();
					signalStre.clear();
				} else {
					Log.w("myApp", "ingen bluetooth devies");
					// Toast.makeText(YourActivity.this, "No New Devices Found",
					// Toast.LENGTH_LONG).show();
				}

			}
		}
	};

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	public void SaveToFile(String FileName) {

		try {
			File sdcard = Environment.getExternalStorageDirectory();
			// to this path add a new directory path
			File dir = new File(sdcard.getAbsolutePath() + "/speciale/");
			// create this directory if not already created
			dir.mkdir();
			// create the file in which we will write the contents
			File file = new File(dir, FileName);

			/*
			 * FileOutputStream outStream = new FileOutputStream(file); String
			 * data = "det virker hello wrod";
			 * 
			 * Csv makeSaveString = new Csv(); data =
			 * makeSaveString.ToCsv(result);
			 * 
			 * 
			 * outStream.write(data.getBytes()); outStream.close();
			 */

			FileOutputStream outStream = new FileOutputStream(file);
			String data = "det virker hello wrod";

			Csv makeSaveString = new Csv();
			data = resultString;// makeSaveString.ToCsv(result);

			FileWriter fw = new FileWriter(file);
			BufferedWriter bw = new BufferedWriter(fw);

			bw.write(data);

			bw.close();
			fw.close();
			data = "";
			resultString = "";

		} catch (Exception e) {
			e.printStackTrace();
		}
		// result.clear();

	}

	int increase = 0;

	public void scanned() {

		Toast.makeText(this, "Saved to denne" + increase + ".txt", Toast.LENGTH_LONG).show();
	}

	public void savePress(View v) {
		increase++;
		SaveToFile("denne" + increase + ".txt");
		Toast.makeText(this, "Saved to denne" + increase + ".txt", Toast.LENGTH_LONG).show();
		Log.w("myApp", "dette kan ses :)");
	}

	public void scan(View v) {
		wifiStop = false;
		// SaveToFile("denne2.txt");
		Toast.makeText(this, "scan", Toast.LENGTH_LONG).show();
		Log.w("myApp", "scan pressed");
		mainWifi.startScan();

	}

	public void walking(View v) {
		Toast.makeText(this, "walking", Toast.LENGTH_LONG).show();
		positionX = -1;
		positionY = -1;
	}

	public void aajj0(View v) {
		positionX = 5;
		positionY = 5;
	}

	public void aajj1(View v) {
		positionX = 11;
		positionY = 4;
	}

	public void aajj2(View v) {
		positionX = 25;
		positionY = 7;
	}

	public void aajj4(View v) {
		positionX = 45;
		positionY = 7;
	}

	public void aajj5(View v) {
		positionX = 58;
		positionY = 3;
	}

	public void aajj6(View v) {
		positionX = 66;
		positionY = 2;
	}

	public void aajj8(View v) {
		positionX = 77;
		positionY = 8;
	}

	public void aajj9(View v) {
		positionX = 95;
		positionY = 5;
	}

	public void aajj10(View v) {
		positionX = 111;
		positionY = 5;
	}

	public void aajj11(View v) {
		positionX = 121;
		positionY = 4;
	}

	public void aajj12(View v) {
		positionX = 147;
		positionY = 2;
	}

	public void aajj13(View v) {
		positionX = 163;
		positionY = 2;
	}

	public void aajj14(View v) {
		positionX = 175;
		positionY = 2;
	}

	public void aajj15(View v) {
		positionX = 184;
		positionY = 3;
	}

	public void aajj16(View v) {
		positionX = 200;
		positionY = 3;
	}

	public void aajj18(View v) {
		positionX = 206;
		positionY = 3;
	}

	public void aajj19(View v) {
		positionX = 227;
		positionY = 8;
	}

	public void aajj20(View v) {
		positionX = 249;
		positionY = 4;
	}

	public void aajj21(View v) {
		positionX = 260;
		positionY = 3;
	}

	public void aajj23(View v) {
		positionX = 281;
		positionY = 4;
	}

	public void aajj24(View v) {
		positionX = 307;
		positionY = 2;
	}

	public void aajj26(View v) {
		positionX = 317;
		positionY = 2;
	}

	public void aajj28(View v) {
		positionX = 347;
		positionY = 2;
	}

	public void aajj29(View v) {
		positionX = 363;
		positionY = 2;
	}

	public void aajj31(View v) {
		positionX = 393;
		positionY = 4;
	}

	public void aajj33(View v) {
		positionX = 402;
		positionY = 6;
	}

	public void aajj34(View v) {
		positionX = 417;
		positionY = 5;
	}

	public void aajj35(View v) {
		positionX = 431;
		positionY = 5;
	}

	public void aajj36(View v) {
		positionX = 443;
		positionY = 6;
	}

	public void aajj37(View v) {
		positionX = 454;
		positionY = 6;
	}

	public void long2(View v) {
		positionX = 2;
		positionY = 0;
	}

	public void long6(View v) {
		positionX = 6;
		positionY = 0;
	}

	public void long10(View v) {
		positionX = 10;
		positionY = 0;
	}

	public void long14(View v) {
		positionX = 14;
		positionY = 0;
	}

	/*
	 * public void short2n0(View v) { positionX = 2; positionY = 0; } public
	 * void short2n1(View v) { positionX = 2; positionY = 239; }
	 * 
	 * 
	 * public void short6n0(View v) { positionX = 6; positionY = 0; } public
	 * void short6n1(View v) { positionX = 6; positionY = 239; }
	 * 
	 * public void short10n0(View v) { positionX = 10; positionY = 0; } public
	 * void short10n1(View v) { positionX = 10; positionY = 239; }
	 * 
	 * 
	 * 
	 * public void short14n0(View v) { positionX = 14; positionY = 0; } public
	 * void short14n1(View v) { positionX = 14; positionY = 239; }
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * public void wifi1(View v) { Toast.makeText(this, "wifi1",
	 * Toast.LENGTH_LONG).show(); positionX = -100; positionY = -100; }
	 */
	public void stop(View v) {
		Toast.makeText(this, "stop", Toast.LENGTH_LONG).show();
		wifiStop = true;
	}

	/*
	 * 
	 * public void wifi2(View v) { Toast.makeText(this, "wifi2",
	 * Toast.LENGTH_LONG).show(); positionX = -200; positionY = -200; }
	 * 
	 * public void wifi3(View v) { Toast.makeText(this, "wifi3",
	 * Toast.LENGTH_LONG).show(); positionX = -300; positionY = -300; }
	 * 
	 * public void wifi4(View v) { Toast.makeText(this, "wifi4",
	 * Toast.LENGTH_LONG).show(); positionX = -400; positionY = -400; }
	 * 
	 * public void wifi5(View v) { Toast.makeText(this, "wifi5",
	 * Toast.LENGTH_LONG).show(); positionX = -500; positionY = -500; }
	 * 
	 * public void wifi6(View v) { Toast.makeText(this, "wifi6",
	 * Toast.LENGTH_LONG).show(); positionX = -600; positionY = -600; }
	 * 
	 * public void wifi7(View v) { Toast.makeText(this, "wifi7",
	 * Toast.LENGTH_LONG).show(); positionX = -700; positionY = -700; }
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * public void blue(View v) {
	 * 
	 * // SaveToFile("denne2.txt"); Toast.makeText(this, "scan",
	 * Toast.LENGTH_LONG).show(); Log.w("myApp", "blue scan pressed");
	 * mBluetoothAdapter.startDiscovery(); }
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * public void All2n0(View v) { positionX = 2; positionY = 0; } public void
	 * All2n4(View v) { positionX = 2; positionY = 4; } public void All2n8(View
	 * v) { positionX = 2; positionY = 8; } public void All2n12(View v) {
	 * positionX = 2; positionY = 12; } public void All2n16(View v) { positionX
	 * = 2; positionY = 16; } public void All2n20(View v) { positionX = 2;
	 * positionY = 20; } public void All2n24(View v) { positionX = 2; positionY
	 * = 24; } public void All2n28(View v) { positionX = 2; positionY = 28; }
	 * public void All2n32(View v) { positionX = 2; positionY = 32; } public
	 * void All2n36(View v) { positionX = 2; positionY = 36; } public void
	 * All2n40(View v) { positionX = 2; positionY = 40; } public void
	 * All2n44(View v) { positionX = 2; positionY = 44; } public void
	 * All2n48(View v) { positionX = 2; positionY = 48; } public void
	 * All2n52(View v) { positionX = 2; positionY = 52; } public void
	 * All2n56(View v) { positionX = 2; positionY = 56; } public void
	 * All2n60(View v) { positionX = 2; positionY = 60; } public void
	 * All2n64(View v) { positionX = 2; positionY = 64; } public void
	 * All2n68(View v) { positionX = 2; positionY = 68; } public void
	 * All2n72(View v) { positionX = 2; positionY = 72; } public void
	 * All2n76(View v) { positionX = 2; positionY = 76; } public void
	 * All2n80(View v) { positionX = 2; positionY = 80; } public void
	 * All2n84(View v) { positionX = 2; positionY = 84; } public void
	 * All2n88(View v) { positionX = 2; positionY = 88; } public void
	 * All2n92(View v) { positionX = 2; positionY = 92; } public void
	 * All2n96(View v) { positionX = 2; positionY = 96; } public void
	 * All2n100(View v) { positionX = 2; positionY = 100; } public void
	 * All2n104(View v) { positionX = 2; positionY = 104; } public void
	 * All2n108(View v) { positionX = 2; positionY = 108; } public void
	 * All2n112(View v) { positionX = 2; positionY = 112; } public void
	 * All2n116(View v) { positionX = 2; positionY = 116; } public void
	 * All2n120(View v) { positionX = 2; positionY = 120; } public void
	 * All2n124(View v) { positionX = 2; positionY = 124; } public void
	 * All2n128(View v) { positionX = 2; positionY = 128; } public void
	 * All2n132(View v) { positionX = 2; positionY = 132; } public void
	 * All2n136(View v) { positionX = 2; positionY = 136; } public void
	 * All2n139(View v) { positionX = 2; positionY = 139; } public void
	 * All2n143(View v) { positionX = 2; positionY = 143; } public void
	 * All2n147(View v) { positionX = 2; positionY = 147; } public void
	 * All2n151(View v) { positionX = 2; positionY = 151; } public void
	 * All2n155(View v) { positionX = 2; positionY = 155; } public void
	 * All2n159(View v) { positionX = 2; positionY = 159; } public void
	 * All2n163(View v) { positionX = 2; positionY = 163; } public void
	 * All2n167(View v) { positionX = 2; positionY = 167; } public void
	 * All2n171(View v) { positionX = 2; positionY = 171; } public void
	 * All2n175(View v) { positionX = 2; positionY = 175; } public void
	 * All2n179(View v) { positionX = 2; positionY = 179; } public void
	 * All2n183(View v) { positionX = 2; positionY = 183; } public void
	 * All2n187(View v) { positionX = 2; positionY = 187; } public void
	 * All2n191(View v) { positionX = 2; positionY = 191; } public void
	 * All2n195(View v) { positionX = 2; positionY = 195; } public void
	 * All2n199(View v) { positionX = 2; positionY = 199; } public void
	 * All2n203(View v) { positionX = 2; positionY = 203; } public void
	 * All2n207(View v) { positionX = 2; positionY = 207; } public void
	 * All2n211(View v) { positionX = 2; positionY = 211; } public void
	 * All2n215(View v) { positionX = 2; positionY = 215; } public void
	 * All2n219(View v) { positionX = 2; positionY = 219; } public void
	 * All2n223(View v) { positionX = 2; positionY = 223; } public void
	 * All2n227(View v) { positionX = 2; positionY = 227; } public void
	 * All2n231(View v) { positionX = 2; positionY = 231; } public void
	 * All2n235(View v) { positionX = 2; positionY = 235; } public void
	 * All2n239(View v) { positionX = 2; positionY = 239; } public void
	 * All2n243(View v) { positionX = 2; positionY = 243; } public void
	 * All2n247(View v) { positionX = 2; positionY = 247; } public void
	 * All2n251(View v) { positionX = 2; positionY = 251; } public void
	 * All2n255(View v) { positionX = 2; positionY = 255; } public void
	 * All2n259(View v) { positionX = 2; positionY = 259; } public void
	 * All2n263(View v) { positionX = 2; positionY = 263; } public void
	 * All2n267(View v) { positionX = 2; positionY = 267; } public void
	 * All2n271(View v) { positionX = 2; positionY = 271; } public void
	 * All2n275(View v) { positionX = 2; positionY = 275; } public void
	 * All2n279(View v) { positionX = 2; positionY = 279; } public void
	 * All2n283(View v) { positionX = 2; positionY = 283; } public void
	 * All2n287(View v) { positionX = 2; positionY = 287; } public void
	 * All2n291(View v) { positionX = 2; positionY = 291; } public void
	 * All2n295(View v) { positionX = 2; positionY = 295; } public void
	 * All2n299(View v) { positionX = 2; positionY = 299; } public void
	 * All2n303(View v) { positionX = 2; positionY = 303; } public void
	 * All2n307(View v) { positionX = 2; positionY = 307; } public void
	 * All2n311(View v) { positionX = 2; positionY = 311; } public void
	 * All2n315(View v) { positionX = 2; positionY = 315; } public void
	 * All2n319(View v) { positionX = 2; positionY = 319; } public void
	 * All2n323(View v) { positionX = 2; positionY = 323; } public void
	 * All2n327(View v) { positionX = 2; positionY = 327; } public void
	 * All2n331(View v) { positionX = 2; positionY = 331; } public void
	 * All2n335(View v) { positionX = 2; positionY = 335; } public void
	 * All2n339(View v) { positionX = 2; positionY = 339; } public void
	 * All2n343(View v) { positionX = 2; positionY = 343; } public void
	 * All2n347(View v) { positionX = 2; positionY = 347; } public void
	 * All2n351(View v) { positionX = 2; positionY = 351; } public void
	 * All2n355(View v) { positionX = 2; positionY = 355; } public void
	 * All2n359(View v) { positionX = 2; positionY = 359; } public void
	 * All2n363(View v) { positionX = 2; positionY = 363; } public void
	 * All2n367(View v) { positionX = 2; positionY = 367; } public void
	 * All2n371(View v) { positionX = 2; positionY = 371; } public void
	 * All2n375(View v) { positionX = 2; positionY = 375; } public void
	 * All2n379(View v) { positionX = 2; positionY = 379; } public void
	 * All2n383(View v) { positionX = 2; positionY = 383; } public void
	 * All2n387(View v) { positionX = 2; positionY = 387; } public void
	 * All2n391(View v) { positionX = 2; positionY = 391; } public void
	 * All2n395(View v) { positionX = 2; positionY = 395; } public void
	 * All2n399(View v) { positionX = 2; positionY = 399; } public void
	 * All2n403(View v) { positionX = 2; positionY = 403; } public void
	 * All2n407(View v) { positionX = 2; positionY = 407; } public void
	 * All2n411(View v) { positionX = 2; positionY = 411; } public void
	 * All2n415(View v) { positionX = 2; positionY = 415; } public void
	 * All2n419(View v) { positionX = 2; positionY = 419; } public void
	 * All2n423(View v) { positionX = 2; positionY = 423; } public void
	 * All2n427(View v) { positionX = 2; positionY = 427; } public void
	 * All2n431(View v) { positionX = 2; positionY = 431; } public void
	 * All2n435(View v) { positionX = 2; positionY = 435; } public void
	 * All2n439(View v) { positionX = 2; positionY = 439; } public void
	 * All2n443(View v) { positionX = 2; positionY = 443; } public void
	 * All2n447(View v) { positionX = 2; positionY = 447; } public void
	 * All2n451(View v) { positionX = 2; positionY = 451; } public void
	 * All2n455(View v) { positionX = 2; positionY = 455; } public void
	 * All2n459(View v) { positionX = 2; positionY = 459; } public void
	 * All2n463(View v) { positionX = 2; positionY = 463; } public void
	 * All2n467(View v) { positionX = 2; positionY = 467; } public void
	 * All2n471(View v) { positionX = 2; positionY = 471; } public void
	 * All2n475(View v) { positionX = 2; positionY = 475; } public void
	 * All6n0(View v) { positionX = 6; positionY = 0; } public void All6n4(View
	 * v) { positionX = 6; positionY = 4; } public void All6n8(View v) {
	 * positionX = 6; positionY = 8; } public void All6n12(View v) { positionX =
	 * 6; positionY = 12; } public void All6n16(View v) { positionX = 6;
	 * positionY = 16; } public void All6n20(View v) { positionX = 6; positionY
	 * = 20; } public void All6n24(View v) { positionX = 6; positionY = 24; }
	 * public void All6n28(View v) { positionX = 6; positionY = 28; } public
	 * void All6n32(View v) { positionX = 6; positionY = 32; } public void
	 * All6n36(View v) { positionX = 6; positionY = 36; } public void
	 * All6n40(View v) { positionX = 6; positionY = 40; } public void
	 * All6n44(View v) { positionX = 6; positionY = 44; } public void
	 * All6n48(View v) { positionX = 6; positionY = 48; } public void
	 * All6n52(View v) { positionX = 6; positionY = 52; } public void
	 * All6n56(View v) { positionX = 6; positionY = 56; } public void
	 * All6n60(View v) { positionX = 6; positionY = 60; } public void
	 * All6n64(View v) { positionX = 6; positionY = 64; } public void
	 * All6n68(View v) { positionX = 6; positionY = 68; } public void
	 * All6n72(View v) { positionX = 6; positionY = 72; } public void
	 * All6n76(View v) { positionX = 6; positionY = 76; } public void
	 * All6n80(View v) { positionX = 6; positionY = 80; } public void
	 * All6n84(View v) { positionX = 6; positionY = 84; } public void
	 * All6n88(View v) { positionX = 6; positionY = 88; } public void
	 * All6n92(View v) { positionX = 6; positionY = 92; } public void
	 * All6n96(View v) { positionX = 6; positionY = 96; } public void
	 * All6n100(View v) { positionX = 6; positionY = 100; } public void
	 * All6n104(View v) { positionX = 6; positionY = 104; } public void
	 * All6n108(View v) { positionX = 6; positionY = 108; } public void
	 * All6n112(View v) { positionX = 6; positionY = 112; } public void
	 * All6n116(View v) { positionX = 6; positionY = 116; } public void
	 * All6n120(View v) { positionX = 6; positionY = 120; } public void
	 * All6n124(View v) { positionX = 6; positionY = 124; } public void
	 * All6n128(View v) { positionX = 6; positionY = 128; } public void
	 * All6n132(View v) { positionX = 6; positionY = 132; } public void
	 * All6n136(View v) { positionX = 6; positionY = 136; } public void
	 * All6n139(View v) { positionX = 6; positionY = 139; } public void
	 * All6n143(View v) { positionX = 6; positionY = 143; } public void
	 * All6n147(View v) { positionX = 6; positionY = 147; } public void
	 * All6n151(View v) { positionX = 6; positionY = 151; } public void
	 * All6n155(View v) { positionX = 6; positionY = 155; } public void
	 * All6n159(View v) { positionX = 6; positionY = 159; } public void
	 * All6n163(View v) { positionX = 6; positionY = 163; } public void
	 * All6n167(View v) { positionX = 6; positionY = 167; } public void
	 * All6n171(View v) { positionX = 6; positionY = 171; } public void
	 * All6n175(View v) { positionX = 6; positionY = 175; } public void
	 * All6n179(View v) { positionX = 6; positionY = 179; } public void
	 * All6n183(View v) { positionX = 6; positionY = 183; } public void
	 * All6n187(View v) { positionX = 6; positionY = 187; } public void
	 * All6n191(View v) { positionX = 6; positionY = 191; } public void
	 * All6n195(View v) { positionX = 6; positionY = 195; } public void
	 * All6n199(View v) { positionX = 6; positionY = 199; } public void
	 * All6n203(View v) { positionX = 6; positionY = 203; } public void
	 * All6n207(View v) { positionX = 6; positionY = 207; } public void
	 * All6n211(View v) { positionX = 6; positionY = 211; } public void
	 * All6n215(View v) { positionX = 6; positionY = 215; } public void
	 * All6n219(View v) { positionX = 6; positionY = 219; } public void
	 * All6n223(View v) { positionX = 6; positionY = 223; } public void
	 * All6n227(View v) { positionX = 6; positionY = 227; } public void
	 * All6n231(View v) { positionX = 6; positionY = 231; } public void
	 * All6n235(View v) { positionX = 6; positionY = 235; } public void
	 * All6n239(View v) { positionX = 6; positionY = 239; } public void
	 * All6n243(View v) { positionX = 6; positionY = 243; } public void
	 * All6n247(View v) { positionX = 6; positionY = 247; } public void
	 * All6n251(View v) { positionX = 6; positionY = 251; } public void
	 * All6n255(View v) { positionX = 6; positionY = 255; } public void
	 * All6n259(View v) { positionX = 6; positionY = 259; } public void
	 * All6n263(View v) { positionX = 6; positionY = 263; } public void
	 * All6n267(View v) { positionX = 6; positionY = 267; } public void
	 * All6n271(View v) { positionX = 6; positionY = 271; } public void
	 * All6n275(View v) { positionX = 6; positionY = 275; } public void
	 * All6n279(View v) { positionX = 6; positionY = 279; } public void
	 * All6n283(View v) { positionX = 6; positionY = 283; } public void
	 * All6n287(View v) { positionX = 6; positionY = 287; } public void
	 * All6n291(View v) { positionX = 6; positionY = 291; } public void
	 * All6n295(View v) { positionX = 6; positionY = 295; } public void
	 * All6n299(View v) { positionX = 6; positionY = 299; } public void
	 * All6n303(View v) { positionX = 6; positionY = 303; } public void
	 * All6n307(View v) { positionX = 6; positionY = 307; } public void
	 * All6n311(View v) { positionX = 6; positionY = 311; } public void
	 * All6n315(View v) { positionX = 6; positionY = 315; } public void
	 * All6n319(View v) { positionX = 6; positionY = 319; } public void
	 * All6n323(View v) { positionX = 6; positionY = 323; } public void
	 * All6n327(View v) { positionX = 6; positionY = 327; } public void
	 * All6n331(View v) { positionX = 6; positionY = 331; } public void
	 * All6n335(View v) { positionX = 6; positionY = 335; } public void
	 * All6n339(View v) { positionX = 6; positionY = 339; } public void
	 * All6n343(View v) { positionX = 6; positionY = 343; } public void
	 * All6n347(View v) { positionX = 6; positionY = 347; } public void
	 * All6n351(View v) { positionX = 6; positionY = 351; } public void
	 * All6n355(View v) { positionX = 6; positionY = 355; } public void
	 * All6n359(View v) { positionX = 6; positionY = 359; } public void
	 * All6n363(View v) { positionX = 6; positionY = 363; } public void
	 * All6n367(View v) { positionX = 6; positionY = 367; } public void
	 * All6n371(View v) { positionX = 6; positionY = 371; } public void
	 * All6n375(View v) { positionX = 6; positionY = 375; } public void
	 * All6n379(View v) { positionX = 6; positionY = 379; } public void
	 * All6n383(View v) { positionX = 6; positionY = 383; } public void
	 * All6n387(View v) { positionX = 6; positionY = 387; } public void
	 * All6n391(View v) { positionX = 6; positionY = 391; } public void
	 * All6n395(View v) { positionX = 6; positionY = 395; } public void
	 * All6n399(View v) { positionX = 6; positionY = 399; } public void
	 * All6n403(View v) { positionX = 6; positionY = 403; } public void
	 * All6n407(View v) { positionX = 6; positionY = 407; } public void
	 * All6n411(View v) { positionX = 6; positionY = 411; } public void
	 * All6n415(View v) { positionX = 6; positionY = 415; } public void
	 * All6n419(View v) { positionX = 6; positionY = 419; } public void
	 * All6n423(View v) { positionX = 6; positionY = 423; } public void
	 * All6n427(View v) { positionX = 6; positionY = 427; } public void
	 * All6n431(View v) { positionX = 6; positionY = 431; } public void
	 * All6n435(View v) { positionX = 6; positionY = 435; } public void
	 * All6n439(View v) { positionX = 6; positionY = 439; } public void
	 * All6n443(View v) { positionX = 6; positionY = 443; } public void
	 * All6n447(View v) { positionX = 6; positionY = 447; } public void
	 * All6n451(View v) { positionX = 6; positionY = 451; } public void
	 * All6n455(View v) { positionX = 6; positionY = 455; } public void
	 * All6n459(View v) { positionX = 6; positionY = 459; } public void
	 * All6n463(View v) { positionX = 6; positionY = 463; } public void
	 * All6n467(View v) { positionX = 6; positionY = 467; } public void
	 * All6n471(View v) { positionX = 6; positionY = 471; } public void
	 * All6n475(View v) { positionX = 6; positionY = 475; } public void
	 * All10n0(View v) { positionX = 10; positionY = 0; } public void
	 * All10n4(View v) { positionX = 10; positionY = 4; } public void
	 * All10n8(View v) { positionX = 10; positionY = 8; } public void
	 * All10n12(View v) { positionX = 10; positionY = 12; } public void
	 * All10n16(View v) { positionX = 10; positionY = 16; } public void
	 * All10n20(View v) { positionX = 10; positionY = 20; } public void
	 * All10n24(View v) { positionX = 10; positionY = 24; } public void
	 * All10n28(View v) { positionX = 10; positionY = 28; } public void
	 * All10n32(View v) { positionX = 10; positionY = 32; } public void
	 * All10n36(View v) { positionX = 10; positionY = 36; } public void
	 * All10n40(View v) { positionX = 10; positionY = 40; } public void
	 * All10n44(View v) { positionX = 10; positionY = 44; } public void
	 * All10n48(View v) { positionX = 10; positionY = 48; } public void
	 * All10n52(View v) { positionX = 10; positionY = 52; } public void
	 * All10n56(View v) { positionX = 10; positionY = 56; } public void
	 * All10n60(View v) { positionX = 10; positionY = 60; } public void
	 * All10n64(View v) { positionX = 10; positionY = 64; } public void
	 * All10n68(View v) { positionX = 10; positionY = 68; } public void
	 * All10n72(View v) { positionX = 10; positionY = 72; } public void
	 * All10n76(View v) { positionX = 10; positionY = 76; } public void
	 * All10n80(View v) { positionX = 10; positionY = 80; } public void
	 * All10n84(View v) { positionX = 10; positionY = 84; } public void
	 * All10n88(View v) { positionX = 10; positionY = 88; } public void
	 * All10n92(View v) { positionX = 10; positionY = 92; } public void
	 * All10n96(View v) { positionX = 10; positionY = 96; } public void
	 * All10n100(View v) { positionX = 10; positionY = 100; } public void
	 * All10n104(View v) { positionX = 10; positionY = 104; } public void
	 * All10n108(View v) { positionX = 10; positionY = 108; } public void
	 * All10n112(View v) { positionX = 10; positionY = 112; } public void
	 * All10n116(View v) { positionX = 10; positionY = 116; } public void
	 * All10n120(View v) { positionX = 10; positionY = 120; } public void
	 * All10n124(View v) { positionX = 10; positionY = 124; } public void
	 * All10n128(View v) { positionX = 10; positionY = 128; } public void
	 * All10n132(View v) { positionX = 10; positionY = 132; } public void
	 * All10n136(View v) { positionX = 10; positionY = 136; } public void
	 * All10n139(View v) { positionX = 10; positionY = 139; } public void
	 * All10n143(View v) { positionX = 10; positionY = 143; } public void
	 * All10n147(View v) { positionX = 10; positionY = 147; } public void
	 * All10n151(View v) { positionX = 10; positionY = 151; } public void
	 * All10n155(View v) { positionX = 10; positionY = 155; } public void
	 * All10n159(View v) { positionX = 10; positionY = 159; } public void
	 * All10n163(View v) { positionX = 10; positionY = 163; } public void
	 * All10n167(View v) { positionX = 10; positionY = 167; } public void
	 * All10n171(View v) { positionX = 10; positionY = 171; } public void
	 * All10n175(View v) { positionX = 10; positionY = 175; } public void
	 * All10n179(View v) { positionX = 10; positionY = 179; } public void
	 * All10n183(View v) { positionX = 10; positionY = 183; } public void
	 * All10n187(View v) { positionX = 10; positionY = 187; } public void
	 * All10n191(View v) { positionX = 10; positionY = 191; } public void
	 * All10n195(View v) { positionX = 10; positionY = 195; } public void
	 * All10n199(View v) { positionX = 10; positionY = 199; } public void
	 * All10n203(View v) { positionX = 10; positionY = 203; } public void
	 * All10n207(View v) { positionX = 10; positionY = 207; } public void
	 * All10n211(View v) { positionX = 10; positionY = 211; } public void
	 * All10n215(View v) { positionX = 10; positionY = 215; } public void
	 * All10n219(View v) { positionX = 10; positionY = 219; } public void
	 * All10n223(View v) { positionX = 10; positionY = 223; } public void
	 * All10n227(View v) { positionX = 10; positionY = 227; } public void
	 * All10n231(View v) { positionX = 10; positionY = 231; } public void
	 * All10n235(View v) { positionX = 10; positionY = 235; } public void
	 * All10n239(View v) { positionX = 10; positionY = 239; } public void
	 * All10n243(View v) { positionX = 10; positionY = 243; } public void
	 * All10n247(View v) { positionX = 10; positionY = 247; } public void
	 * All10n251(View v) { positionX = 10; positionY = 251; } public void
	 * All10n255(View v) { positionX = 10; positionY = 255; } public void
	 * All10n259(View v) { positionX = 10; positionY = 259; } public void
	 * All10n263(View v) { positionX = 10; positionY = 263; } public void
	 * All10n267(View v) { positionX = 10; positionY = 267; } public void
	 * All10n271(View v) { positionX = 10; positionY = 271; } public void
	 * All10n275(View v) { positionX = 10; positionY = 275; } public void
	 * All10n279(View v) { positionX = 10; positionY = 279; } public void
	 * All10n283(View v) { positionX = 10; positionY = 283; } public void
	 * All10n287(View v) { positionX = 10; positionY = 287; } public void
	 * All10n291(View v) { positionX = 10; positionY = 291; } public void
	 * All10n295(View v) { positionX = 10; positionY = 295; } public void
	 * All10n299(View v) { positionX = 10; positionY = 299; } public void
	 * All10n303(View v) { positionX = 10; positionY = 303; } public void
	 * All10n307(View v) { positionX = 10; positionY = 307; } public void
	 * All10n311(View v) { positionX = 10; positionY = 311; } public void
	 * All10n315(View v) { positionX = 10; positionY = 315; } public void
	 * All10n319(View v) { positionX = 10; positionY = 319; } public void
	 * All10n323(View v) { positionX = 10; positionY = 323; } public void
	 * All10n327(View v) { positionX = 10; positionY = 327; } public void
	 * All10n331(View v) { positionX = 10; positionY = 331; } public void
	 * All10n335(View v) { positionX = 10; positionY = 335; } public void
	 * All10n339(View v) { positionX = 10; positionY = 339; } public void
	 * All10n343(View v) { positionX = 10; positionY = 343; } public void
	 * All10n347(View v) { positionX = 10; positionY = 347; } public void
	 * All10n351(View v) { positionX = 10; positionY = 351; } public void
	 * All10n355(View v) { positionX = 10; positionY = 355; } public void
	 * All10n359(View v) { positionX = 10; positionY = 359; } public void
	 * All10n363(View v) { positionX = 10; positionY = 363; } public void
	 * All10n367(View v) { positionX = 10; positionY = 367; } public void
	 * All10n371(View v) { positionX = 10; positionY = 371; } public void
	 * All10n375(View v) { positionX = 10; positionY = 375; } public void
	 * All10n379(View v) { positionX = 10; positionY = 379; } public void
	 * All10n383(View v) { positionX = 10; positionY = 383; } public void
	 * All10n387(View v) { positionX = 10; positionY = 387; } public void
	 * All10n391(View v) { positionX = 10; positionY = 391; } public void
	 * All10n395(View v) { positionX = 10; positionY = 395; } public void
	 * All10n399(View v) { positionX = 10; positionY = 399; } public void
	 * All10n403(View v) { positionX = 10; positionY = 403; } public void
	 * All10n407(View v) { positionX = 10; positionY = 407; } public void
	 * All10n411(View v) { positionX = 10; positionY = 411; } public void
	 * All10n415(View v) { positionX = 10; positionY = 415; } public void
	 * All10n419(View v) { positionX = 10; positionY = 419; } public void
	 * All10n423(View v) { positionX = 10; positionY = 423; } public void
	 * All10n427(View v) { positionX = 10; positionY = 427; } public void
	 * All10n431(View v) { positionX = 10; positionY = 431; } public void
	 * All10n435(View v) { positionX = 10; positionY = 435; } public void
	 * All10n439(View v) { positionX = 10; positionY = 439; } public void
	 * All10n443(View v) { positionX = 10; positionY = 443; } public void
	 * All10n447(View v) { positionX = 10; positionY = 447; } public void
	 * All10n451(View v) { positionX = 10; positionY = 451; } public void
	 * All10n455(View v) { positionX = 10; positionY = 455; } public void
	 * All10n459(View v) { positionX = 10; positionY = 459; } public void
	 * All10n463(View v) { positionX = 10; positionY = 463; } public void
	 * All10n467(View v) { positionX = 10; positionY = 467; } public void
	 * All10n471(View v) { positionX = 10; positionY = 471; } public void
	 * All10n475(View v) { positionX = 10; positionY = 475; } public void
	 * All14n0(View v) { positionX = 14; positionY = 0; } public void
	 * All14n4(View v) { positionX = 14; positionY = 4; } public void
	 * All14n8(View v) { positionX = 14; positionY = 8; } public void
	 * All14n12(View v) { positionX = 14; positionY = 12; } public void
	 * All14n16(View v) { positionX = 14; positionY = 16; } public void
	 * All14n20(View v) { positionX = 14; positionY = 20; } public void
	 * All14n24(View v) { positionX = 14; positionY = 24; } public void
	 * All14n28(View v) { positionX = 14; positionY = 28; } public void
	 * All14n32(View v) { positionX = 14; positionY = 32; } public void
	 * All14n36(View v) { positionX = 14; positionY = 36; } public void
	 * All14n40(View v) { positionX = 14; positionY = 40; } public void
	 * All14n44(View v) { positionX = 14; positionY = 44; } public void
	 * All14n48(View v) { positionX = 14; positionY = 48; } public void
	 * All14n52(View v) { positionX = 14; positionY = 52; } public void
	 * All14n56(View v) { positionX = 14; positionY = 56; } public void
	 * All14n60(View v) { positionX = 14; positionY = 60; } public void
	 * All14n64(View v) { positionX = 14; positionY = 64; } public void
	 * All14n68(View v) { positionX = 14; positionY = 68; } public void
	 * All14n72(View v) { positionX = 14; positionY = 72; } public void
	 * All14n76(View v) { positionX = 14; positionY = 76; } public void
	 * All14n80(View v) { positionX = 14; positionY = 80; } public void
	 * All14n84(View v) { positionX = 14; positionY = 84; } public void
	 * All14n88(View v) { positionX = 14; positionY = 88; } public void
	 * All14n92(View v) { positionX = 14; positionY = 92; } public void
	 * All14n96(View v) { positionX = 14; positionY = 96; } public void
	 * All14n100(View v) { positionX = 14; positionY = 100; } public void
	 * All14n104(View v) { positionX = 14; positionY = 104; } public void
	 * All14n108(View v) { positionX = 14; positionY = 108; } public void
	 * All14n112(View v) { positionX = 14; positionY = 112; } public void
	 * All14n116(View v) { positionX = 14; positionY = 116; } public void
	 * All14n120(View v) { positionX = 14; positionY = 120; } public void
	 * All14n124(View v) { positionX = 14; positionY = 124; } public void
	 * All14n128(View v) { positionX = 14; positionY = 128; } public void
	 * All14n132(View v) { positionX = 14; positionY = 132; } public void
	 * All14n136(View v) { positionX = 14; positionY = 136; } public void
	 * All14n139(View v) { positionX = 14; positionY = 139; } public void
	 * All14n143(View v) { positionX = 14; positionY = 143; } public void
	 * All14n147(View v) { positionX = 14; positionY = 147; } public void
	 * All14n151(View v) { positionX = 14; positionY = 151; } public void
	 * All14n155(View v) { positionX = 14; positionY = 155; } public void
	 * All14n159(View v) { positionX = 14; positionY = 159; } public void
	 * All14n163(View v) { positionX = 14; positionY = 163; } public void
	 * All14n167(View v) { positionX = 14; positionY = 167; } public void
	 * All14n171(View v) { positionX = 14; positionY = 171; } public void
	 * All14n175(View v) { positionX = 14; positionY = 175; } public void
	 * All14n179(View v) { positionX = 14; positionY = 179; } public void
	 * All14n183(View v) { positionX = 14; positionY = 183; } public void
	 * All14n187(View v) { positionX = 14; positionY = 187; } public void
	 * All14n191(View v) { positionX = 14; positionY = 191; } public void
	 * All14n195(View v) { positionX = 14; positionY = 195; } public void
	 * All14n199(View v) { positionX = 14; positionY = 199; } public void
	 * All14n203(View v) { positionX = 14; positionY = 203; } public void
	 * All14n207(View v) { positionX = 14; positionY = 207; } public void
	 * All14n211(View v) { positionX = 14; positionY = 211; } public void
	 * All14n215(View v) { positionX = 14; positionY = 215; } public void
	 * All14n219(View v) { positionX = 14; positionY = 219; } public void
	 * All14n223(View v) { positionX = 14; positionY = 223; } public void
	 * All14n227(View v) { positionX = 14; positionY = 227; } public void
	 * All14n231(View v) { positionX = 14; positionY = 231; } public void
	 * All14n235(View v) { positionX = 14; positionY = 235; } public void
	 * All14n239(View v) { positionX = 14; positionY = 239; } public void
	 * All14n243(View v) { positionX = 14; positionY = 243; } public void
	 * All14n247(View v) { positionX = 14; positionY = 247; } public void
	 * All14n251(View v) { positionX = 14; positionY = 251; } public void
	 * All14n255(View v) { positionX = 14; positionY = 255; } public void
	 * All14n259(View v) { positionX = 14; positionY = 259; } public void
	 * All14n263(View v) { positionX = 14; positionY = 263; } public void
	 * All14n267(View v) { positionX = 14; positionY = 267; } public void
	 * All14n271(View v) { positionX = 14; positionY = 271; } public void
	 * All14n275(View v) { positionX = 14; positionY = 275; } public void
	 * All14n279(View v) { positionX = 14; positionY = 279; } public void
	 * All14n283(View v) { positionX = 14; positionY = 283; } public void
	 * All14n287(View v) { positionX = 14; positionY = 287; } public void
	 * All14n291(View v) { positionX = 14; positionY = 291; } public void
	 * All14n295(View v) { positionX = 14; positionY = 295; } public void
	 * All14n299(View v) { positionX = 14; positionY = 299; } public void
	 * All14n303(View v) { positionX = 14; positionY = 303; } public void
	 * All14n307(View v) { positionX = 14; positionY = 307; } public void
	 * All14n311(View v) { positionX = 14; positionY = 311; } public void
	 * All14n315(View v) { positionX = 14; positionY = 315; } public void
	 * All14n319(View v) { positionX = 14; positionY = 319; } public void
	 * All14n323(View v) { positionX = 14; positionY = 323; } public void
	 * All14n327(View v) { positionX = 14; positionY = 327; } public void
	 * All14n331(View v) { positionX = 14; positionY = 331; } public void
	 * All14n335(View v) { positionX = 14; positionY = 335; } public void
	 * All14n339(View v) { positionX = 14; positionY = 339; } public void
	 * All14n343(View v) { positionX = 14; positionY = 343; } public void
	 * All14n347(View v) { positionX = 14; positionY = 347; } public void
	 * All14n351(View v) { positionX = 14; positionY = 351; } public void
	 * All14n355(View v) { positionX = 14; positionY = 355; } public void
	 * All14n359(View v) { positionX = 14; positionY = 359; } public void
	 * All14n363(View v) { positionX = 14; positionY = 363; } public void
	 * All14n367(View v) { positionX = 14; positionY = 367; } public void
	 * All14n371(View v) { positionX = 14; positionY = 371; } public void
	 * All14n375(View v) { positionX = 14; positionY = 375; } public void
	 * All14n379(View v) { positionX = 14; positionY = 379; } public void
	 * All14n383(View v) { positionX = 14; positionY = 383; } public void
	 * All14n387(View v) { positionX = 14; positionY = 387; } public void
	 * All14n391(View v) { positionX = 14; positionY = 391; } public void
	 * All14n395(View v) { positionX = 14; positionY = 395; } public void
	 * All14n399(View v) { positionX = 14; positionY = 399; } public void
	 * All14n403(View v) { positionX = 14; positionY = 403; } public void
	 * All14n407(View v) { positionX = 14; positionY = 407; } public void
	 * All14n411(View v) { positionX = 14; positionY = 411; } public void
	 * All14n415(View v) { positionX = 14; positionY = 415; } public void
	 * All14n419(View v) { positionX = 14; positionY = 419; } public void
	 * All14n423(View v) { positionX = 14; positionY = 423; } public void
	 * All14n427(View v) { positionX = 14; positionY = 427; } public void
	 * All14n431(View v) { positionX = 14; positionY = 431; } public void
	 * All14n435(View v) { positionX = 14; positionY = 435; } public void
	 * All14n439(View v) { positionX = 14; positionY = 439; } public void
	 * All14n443(View v) { positionX = 14; positionY = 443; } public void
	 * All14n447(View v) { positionX = 14; positionY = 447; } public void
	 * All14n451(View v) { positionX = 14; positionY = 451; } public void
	 * All14n455(View v) { positionX = 14; positionY = 455; } public void
	 * All14n459(View v) { positionX = 14; positionY = 459; } public void
	 * All14n463(View v) { positionX = 14; positionY = 463; } public void
	 * All14n467(View v) { positionX = 14; positionY = 467; } public void
	 * All14n471(View v) { positionX = 14; positionY = 471; } public void
	 * All14n475(View v) { positionX = 14; positionY = 475; } <Button
	 * android:id="@+id/aajj0" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="5,5" android:onClick="aajj0" />
	 * 
	 * <Button android:id="@+id/aajj1" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="11,4" android:onClick="aajj1" />
	 * 
	 * <Button android:id="@+id/aajj2" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="25,7" android:onClick="aajj2" />
	 * 
	 * <Button android:id="@+id/jj3" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="******" android:onClick="ghjk" />
	 * 
	 * <Button android:id="@+id/aajj4" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="45,7" android:onClick="aajj4" />
	 * 
	 * <Button android:id="@+id/aajj5" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="58,3" android:onClick="aajj5" />
	 * 
	 * <Button android:id="@+id/temp1" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="walking" android:background="@color/green"
	 * android:onClick="walking" />
	 * 
	 * <Button android:id="@+id/aajj6" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="66,2" android:onClick="aajj6" />
	 * 
	 * <Button android:id="@+id/jj7" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="******" android:onClick="ghjk" />
	 * 
	 * <Button android:id="@+id/aajj8" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="77,8" android:onClick="aajj8" />
	 * 
	 * <Button android:id="@+id/aajj9" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="95,5" android:onClick="aajj9" />
	 * 
	 * <Button android:id="@+id/aajj10" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="111,5" android:onClick="aajj10" />
	 * 
	 * <Button android:id="@+id/aajj11" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="121,4" android:onClick="aajj11" />
	 * 
	 * <Button android:id="@+id/temp2" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="walking" android:background="@color/green"
	 * android:onClick="walking" />
	 * 
	 * <Button android:id="@+id/aajj12" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="147,2" android:onClick="aajj12" />
	 * 
	 * <Button android:id="@+id/aajj13" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="163,2" android:onClick="aajj13" />
	 * 
	 * <Button android:id="@+id/aajj14" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="175,2" android:onClick="aajj14" />
	 * 
	 * <Button android:id="@+id/aajj15" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="184,3" android:onClick="aajj15" />
	 * 
	 * <Button android:id="@+id/aajj16" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="200,3" android:onClick="aajj16" />
	 * 
	 * <Button android:id="@+id/jj17" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="******" android:onClick="ghjk" />
	 * 
	 * <Button android:id="@+id/temp3" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="walking" android:background="@color/green"
	 * android:onClick="walking" />
	 * 
	 * <Button android:id="@+id/aajj18" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="206,3" android:onClick="aajj18" />
	 * 
	 * <Button android:id="@+id/aajj19" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="227,8" android:onClick="aajj19" />
	 * 
	 * <Button android:id="@+id/aajj20" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="249,4" android:onClick="aajj20" />
	 * 
	 * <Button android:id="@+id/aajj21" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="260,3" android:onClick="aajj21" />
	 * 
	 * <Button android:id="@+id/jj22" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="******" android:onClick="ghjk" />
	 * 
	 * <Button android:id="@+id/aajj23" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="281,4" android:onClick="aajj23" />
	 * 
	 * <Button android:id="@+id/temp4" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="walking" android:background="@color/green"
	 * android:onClick="walking" />
	 * 
	 * <Button android:id="@+id/aajj24" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="307,2" android:onClick="aajj24" />
	 * 
	 * <Button android:id="@+id/jj25" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="******" android:onClick="ghjk" />
	 * 
	 * <Button android:id="@+id/aajj26" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="317,2" android:onClick="aajj26" />
	 * 
	 * <Button android:id="@+id/jj27" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="******" android:onClick="ghjk" />
	 * 
	 * <Button android:id="@+id/aajj28" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="347,2" android:onClick="aajj28" />
	 * 
	 * <Button android:id="@+id/aajj29" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="363,2" android:onClick="aajj29" />
	 * 
	 * <Button android:id="@+id/temp5" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="walking" android:background="@color/green"
	 * android:onClick="walking" />
	 * 
	 * <Button android:id="@+id/jj30" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="******" android:onClick="ghjk" />
	 * 
	 * <Button android:id="@+id/aajj31" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="393,4" android:onClick="aajj31" />
	 * 
	 * <Button android:id="@+id/jj32" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="******" android:onClick="ghjk" />
	 * 
	 * <Button android:id="@+id/aajj33" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="402,6" android:onClick="aajj33" />
	 * 
	 * <Button android:id="@+id/aajj34" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="417,5" android:onClick="aajj34" />
	 * 
	 * <Button android:id="@+id/aajj35" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="431,5" android:onClick="aajj35" />
	 * 
	 * <Button android:id="@+id/temp6" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="walking" android:background="@color/green"
	 * android:onClick="walking" />
	 * 
	 * <Button android:id="@+id/aajj36" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="443,6" android:onClick="aajj36" />
	 * 
	 * <Button android:id="@+id/aajj37" android:layout_marginTop="5dp"
	 * android:layout_width="match_parent" android:layout_height="wrap_content"
	 * android:text="454,6" android:onClick="aajj37" />
	 * 
	 */

	// wifi

	class WifiReceiver extends BroadcastReceiver {

		int time = 0;
		long TimestampStart = 0;
		long end = 0;

		@Override
		public void onReceive(Context c, Intent intent) {
			// time++;
			// if (time == 1)
			TimestampStart = System.currentTimeMillis();

			sb = new StringBuilder();
			wifiList = mainWifi.getScanResults();

			List<ScanResult> wifiList2;

			String action = intent.getAction();
			/*
			 * if(BluetoothDevice.ACTION_FOUND.equals(action)) { int rssi =
			 * intent.getShortExtra(BluetoothDevice.EXTRA_RSSI,Short.MIN_VALUE);
			 * String name = intent.getStringExtra(BluetoothDevice.EXTRA_NAME);
			 * Log.w("myApp", name+" "+rssi); Log.w("myApp", "found bluetooth");
			 * } else {
			 * 
			 * Log.w("myApp", "!!!!!      found bluetooth      !!!!!!");
			 * 
			 * }
			 */

			for (int i = 0; i < wifiList.size(); i++) {

				/*
				 * sb.append(new Integer(i+1).toString() + ".");
				 * sb.append((wifiList.get(i)).toString()); sb.append("\\n");
				 */

				// Log.w("myApp",wifiList.get(i).toString());

				// inds�t noget der ikke viser hvis dette ikke er aktiveret

				String bssid = wifiList.get(i).BSSID;
				int dbm = wifiList.get(i).level;
				Log.w("myApp", bssid + " " + dbm);

				boolean walking = false;
				if (positionX == -1) {
					// temp.SetWalking(true);
					walking = true;
					Log.w("--------------------true---------------", bssid + " " + dbm);
				} else {
					// temp.SetWalking(false);
					walking = false;
					Log.w("--------------------false---------------", bssid + " " + dbm);
				}

				// temp.setDbm(dbm);
				// temp.setBssid(bssid);
				// temp.setTimestamp(TimestampStart);

				String temp123 = positionX + "," + positionY + "," + walking + "," + bssid + "," + dbm + ","
						+ TimestampStart + "," + "\n";

				// temp123 = temp123 + temp123 + temp123 + temp123;

				resultString = resultString + temp123;

				// result.add(temp);

			}

			Log.w("myApp", "--------------------------");
			mainWifi.disconnect();
			// if (time < 100) {
			if (wifiStop == false)
				mainWifi.startScan();

			// } else {
			// end = System.currentTimeMillis();

			// long timeresult = end - start;

			// Log.w("myApp", "time : "+timeresult);

			// }

			// Log.w("myApp", sb.toString());
		}

	}

}
