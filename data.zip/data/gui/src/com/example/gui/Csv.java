package com.example.gui;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import android.util.Log;

public class Csv {

	public String ToCsv(ArrayList<Point> Mea) {
		String result = "";

		for (Point temp : Mea) {

			result = result + temp.getX() + "," + temp.getY() + "," + temp.getWalking() + "," + temp.getBssid() + ","
					+ temp.getDbm() + "," + temp.getTimestamp() + "," + "\n";

		}

		return result;

	}

	public ArrayList<Point> FromCsv(String csv) {
		ArrayList<Point> result = new ArrayList();

		String[] parts1 = csv.split(",");
		ArrayList<String> parts2 = new ArrayList(Arrays.asList(parts1));

		// hvis der f.eks kun er en x og y koordinater er der kun 2 dele +
		// linieskift
		int number_of_parts = 3;

		int yy = 0;
		while (yy < parts2.size()) {

			double value1 = Double.parseDouble(parts2.get(yy));
			double value2 = Double.parseDouble(parts2.get(yy + 1));

			// System.out.println(value1);
			// System.out.println(value2);

			result.add(new Point(value1, value2));

			yy = yy + number_of_parts;
		}

		return result;

	}

	public void SaveToFile(String FileName, ArrayList<Point> content) {

		// try {

		try {
			FileWriter fw = new FileWriter(FileName);
			BufferedWriter bw = new BufferedWriter(fw);
			String text = ToCsv(content);

			Log.v("-------------------- myApp426", "converted gem ---------------------- ");
			bw.write(text);

			bw.close();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/*
		 * PrintWriter out = new PrintWriter(FileName); String text =
		 * ToCsv(content);
		 * 
		 * // System.out.println(text);
		 * 
		 * out.println(text); out.close(); } catch (FileNotFoundException e) {
		 * System.out.println(e); e.printStackTrace(); }
		 */
		System.out.println("saved");
	}

	public ArrayList<Point> LoadFromFile(String FileName) {
		ArrayList<Point> result = new ArrayList<Point>();
		String textresult = "";
		try {
			FileInputStream inputStream = new FileInputStream(FileName);
			Scanner s = new Scanner(inputStream);
			textresult = s.hasNext() ? s.next() : "";

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		}

		result = FromCsv(textresult);
		System.out.println("loaded");
		return result;
	}

	public Csv() {
		/*
		 * System.out.println("program start"); ArrayList<Point> Measurements =
		 * new ArrayList();
		 * 
		 * Measurements.add(new Point(1, 2)); Measurements.add(new Point(3, 4));
		 * Measurements.add(new Point(5, 6)); Measurements.add(new Point(7, 8));
		 * 
		 * String test1 = "";
		 * 
		 * SaveToFile("test.txt", Measurements); Measurements =
		 * LoadFromFile("test.txt");
		 */

		/*
		 * test1 = ToCsv(Measurements); // System.out.println(test1);
		 * 
		 * ArrayList<Point> test2 = new ArrayList(); test2 = FromCsv(test1);
		 * 
		 * String same = ToCsv(test2); // System.out.println(same);
		 * 
		 */

		// System.out.println("program end");

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		new Csv();
	}

}
